/**
 * Swasthya Connect — Community Healthcare Access Platform
 * Technical Core: Gap Analysis Engine, State Management, Map, Charts, PIN Code API & UI Logic
 */

(function () {
  'use strict';

  // --- Multilingual Translations ---
  const i18n = {
    en: {
      appName: "Swasthya Connect",
      appTagline: "Community Healthcare Access Platform",
      demoBadge: "Demo Prototype — Fictional Data",
      demoSubtitle: "Illustrative sample data for demonstration. Not official government or diagnostic records.",
      navHome: "Home",
      navDashboard: "Gap Dashboard",
      navCamps: "Find Camps",
      navFacilities: "Healthcare Directory",
      navMap: "Priority Map",
      navEducation: "Outreach & Education",
      navAdmin: "Manage & Outreach",
      quickSearchPlaceholder: "Enter 6-digit PIN code (e.g. 413120, 411001), village, or city...",
      searchBtn: "Search",
      heroTitle: "Bridging Community Healthcare Gaps Through Data & Outreach",
      heroDesc: "A dual-purpose platform helping residents discover nearby health camps and facilities, while empowering administrators to identify underserved communities.",
      findCampsBtn: "Find Upcoming Health Camps",
      viewDashboardBtn: "Explore Gap Dashboard",
      totalCommunities: "Communities Monitored",
      totalCamps: "Health Camps Listed",
      totalFacilities: "Public Facilities",
      underservedAreas: "High Priority Gaps",
      statScreenedTotal: "Total People Screened",
      statAvgCoverage: "Avg Screening Coverage",
      benchmarkNotice: "Prototype benchmark: <20% coverage indicates priority assessment needed.",
      filterAll: "All",
      filterUpcoming: "Upcoming",
      filterCompleted: "Completed",
      filterToday: "Happening This Week",
      serviceTypes: "Service Types",
      facilityTypes: "Facility Types",
      priorityHigh: "High Priority",
      priorityMedium: "Medium Priority",
      priorityLow: "Low Priority",
      scheduleCampAction: "Schedule Outreach Camp",
      recordAttendanceAction: "Record Attendance",
      setReminderAction: "Set Reminder",
      directionsAction: "Get Directions",
      eligibilityLabel: "Eligibility",
      venueLabel: "Venue",
      contactLabel: "Contact",
      instructionsLabel: "Instructions",
      operatingHoursLabel: "Operating Hours",
      servicesOfferedLabel: "Services Offered",
      distanceKmLabel: "Distance",
      lowBandwidthMode: "Low-Bandwidth Mode",
      walkthroughBtn: "⚡ 1-Click Demo Scenario",
      resetDataBtn: "Reset Demo Data",
      pinResolving: "Connecting to Postal PIN Code API...",
      pinResolved: "Postal Area Verified",
      pinNoCampsNearby: "No scheduled camps currently in this exact PIN. Showing nearby healthcare facilities & outreach camps in your district.",
      requestCampInPin: "Request Outreach Camp in this PIN",
      postalApiTag: "India Post API Verified",
      navRegister: "Register Visit",
      registerTitle: "Citizen Registration for Nearest Health Centre",
      registerDesc: "Pre-register to visit your nearest Primary Health Centre (PHC), hospital, or health camp. Receive an official digital token pass to present at the clinic reception desk.",
      registerTabNew: "Book Centre Visit",
      registerTabPasses: "My Registered Passes",
      btnBookVisit: "Book Visit & Get Token Pass",
      visitPassTitle: "Official Digital Visit Token",
      tokenNumLabel: "Token Number",
      patientNameLabel: "Patient Name",
      ageGenderLabel: "Age / Gender",
      contactPhoneLabel: "Mobile Contact",
      centerSelectedLabel: "Selected Healthcare Centre",
      serviceNeededLabel: "Service Requested",
      visitDateSlotLabel: "Date & Time Slot"
    },
    hi: {
      appName: "स्वास्थ्य कनेक्ट",
      appTagline: "सामुदायिक स्वास्थ्य सेवा मंच",
      demoBadge: "डेमो प्रोटोटाइप — काल्पनिक डेटा",
      demoSubtitle: "प्रदर्शनी हेतु सांकेतिक डेटा। यह आधिकारिक सरकारी या चिकित्सीय रिकॉर्ड नहीं है।",
      navHome: "होम",
      navDashboard: "गैप डैशबोर्ड",
      navCamps: "शिविर खोजें",
      navFacilities: "स्वास्थ्य निर्देशिका",
      navMap: "प्राथमिकता मानचित्र",
      navEducation: "जागरूकता व सलाह",
      navAdmin: "प्रबंधन व ट्रैकिंग",
      quickSearchPlaceholder: "6-अंकों का पिन कोड (उदा. 413120, 411001), गाँव या शहर दर्ज करें...",
      searchBtn: "खोजें",
      heroTitle: "डेटा और आउटरीच से सामुदायिक स्वास्थ्य अंतराल को पाटना",
      heroDesc: "एक एकीकृत मंच जो नागरिकों को नजदीकी स्वास्थ्य शिविरों और अस्पतालों से जोड़ता है, और प्रशासकों को वंचित क्षेत्रों की पहचान कराता है।",
      findCampsBtn: "आगामी स्वास्थ्य शिविर खोजें",
      viewDashboardBtn: "गैप डैशबोर्ड देखें",
      totalCommunities: "निगरानी क्षेत्र",
      totalCamps: "स्वास्थ्य शिविर",
      totalFacilities: "सरकारी स्वास्थ्य केंद्र",
      underservedAreas: "उच्च प्राथमिकता अंतराल",
      statScreenedTotal: "कुल जांचे गए नागरिक",
      statAvgCoverage: "औसत स्क्रीनिंग कवरेज",
      benchmarkNotice: "प्रोटोटाइप मानक: <20% कवरेज तत्काल आउटरीच का संकेत देता है।",
      filterAll: "सभी",
      filterUpcoming: "आगामी",
      filterCompleted: "संपन्न",
      filterToday: "इस सप्ताह",
      serviceTypes: "सेवा प्रकार",
      facilityTypes: "सुविधा प्रकार",
      priorityHigh: "उच्च प्राथमिकता",
      priorityMedium: "मध्यम प्राथमिकता",
      priorityLow: "निम्न प्राथमिकता",
      scheduleCampAction: "शिविर आयोजित करें",
      recordAttendanceAction: "उपस्थिति दर्ज करें",
      setReminderAction: "स्मरणपत्र सेट करें",
      directionsAction: "दिशा-निर्देश",
      eligibilityLabel: "पात्रता",
      venueLabel: "स्थान",
      contactLabel: "संपर्क",
      instructionsLabel: "निर्देश",
      operatingHoursLabel: "कार्य समय",
      servicesOfferedLabel: "उपलब्ध सेवाएं",
      distanceKmLabel: "दूरी",
      lowBandwidthMode: "कम बैंडविड्थ मोड",
      walkthroughBtn: "⚡ डेमो परिदृश्य (विलेज B)",
      resetDataBtn: "डेटा रीसेट करें",
      pinResolving: "पोस्टल पिन कोड एपीआई से कनेक्ट हो रहा है...",
      pinResolved: "सत्यापित डाक क्षेत्र",
      pinNoCampsNearby: "इस पिन कोड में फिलहाल कोई सक्रिय शिविर नहीं है। आपके जिले की निकटतम स्वास्थ्य सुविधाएं नीचे हैं।",
      requestCampInPin: "इस पिन कोड में शिविर आयोजित करने का अनुरोध करें",
      postalApiTag: "डाक विभाग API द्वारा सत्यापित",
      navRegister: "दौरा पंजीकरण",
      registerTitle: "निकटतम स्वास्थ्य केंद्र हेतु नागरिक पंजीकरण",
      registerDesc: "अपने नजदीकी प्राथमिक स्वास्थ्य केंद्र (PHC), अस्पताल या स्वास्थ्य शिविर में जाने हेतु पूर्व-पंजीकरण करें और स्वागत पटल हेतु आधिकारिक डिजिटल टोकन पास प्राप्त करें।",
      registerTabNew: "नया दौरा बुक करें",
      registerTabPasses: "मेरे पंजीकृत पास",
      btnBookVisit: "दौरा बुक करें व टोकन पास प्राप्त करें",
      visitPassTitle: "आधिकारिक डिजिटल विजिट टोकन",
      tokenNumLabel: "टोकन संख्या",
      patientNameLabel: "नागरिक का नाम",
      ageGenderLabel: "आयु / लिंग",
      contactPhoneLabel: "मोबाइल नंबर",
      centerSelectedLabel: "चयनित स्वास्थ्य केंद्र",
      serviceNeededLabel: "वांछित स्वास्थ्य सेवा",
      visitDateSlotLabel: "तिथि व समय स्लॉट"
    },
    mr: {
      appName: "स्वास्थ्य कनेक्ट",
      appTagline: "सामुदायिक आरोग्य प्रवेश मंच",
      demoBadge: "डेमो प्रोटोटाइप — काल्पनिक डेटा",
      demoSubtitle: "केवळ प्रात्यक्षिकासाठी काल्पनिक डेटा. हे अधिकृत सरकारी किंवा वैद्यकीय अभिलेख नाहीत.",
      navHome: "मुख्यपृष्ठ",
      navDashboard: "तूट डॅशबोर्ड",
      navCamps: "आरोग्य शिबिरे",
      navFacilities: "आरोग्य केंद्रे",
      navMap: "प्राधान्य नकाशा",
      navEducation: "मार्गदर्शन व शिक्षण",
      navAdmin: "शिबिर व्यवस्थापन",
      quickSearchPlaceholder: "६ अंकी पिन कोड (उदा. 413120, 411001), गाव किंवा शहर टाका...",
      searchBtn: "शोधा",
      heroTitle: "माहिती व शिबिरांच्या माध्यमातून आरोग्य सेवेतील तूट भरून काढणे",
      heroDesc: "नागरिकांना मोफत आरोग्य शिबिरे व शासकीय रुग्णालये शोधण्यास मदत करणारा आणि प्रशासनाला दुर्लक्षित गावे ओळखणारा मंच.",
      findCampsBtn: "आगामी आरोग्य शिबिरे शोधा",
      viewDashboardBtn: "तूट विश्लेषण डॅशबोर्ड",
      totalCommunities: "निरीक्षणाखालील गावे",
      totalCamps: "नोंदणीकृत शिबिरे",
      totalFacilities: "शासकीय आरोग्य केंद्रे",
      underservedAreas: "तातडीचे दुर्लक्षित क्षेत्र",
      statScreenedTotal: "एकूण तपासणी केलेले नागरिक",
      statAvgCoverage: "सरासरी तपासणी प्रमाण",
      benchmarkNotice: "प्रोटोटाइप गृहीतक: २०% पेक्षा कमी कव्हरेज असलेल्या भागात तातडीने शिबिराची गरज आहे.",
      filterAll: "सर्व",
      filterUpcoming: "आगामी",
      filterCompleted: "पूर्ण झालेले",
      filterToday: "या आठवड्यातील",
      serviceTypes: "सेवेचे प्रकार",
      facilityTypes: "केंद्राचे प्रकार",
      priorityHigh: "उच्च प्राधान्य",
      priorityMedium: "मध्यम प्राधान्य",
      priorityLow: "कमी प्राधान्य",
      scheduleCampAction: "आरोग्य शिबिर योजा",
      recordAttendanceAction: "उपस्थिती नोंदवा",
      setReminderAction: "आठवण स्मरणपत्र",
      directionsAction: "रस्ता व नकाशे",
      eligibilityLabel: "पात्रता",
      venueLabel: "स्थळ",
      contactLabel: "संपर्क",
      instructionsLabel: "सूचना",
      operatingHoursLabel: "कामाचे तास",
      servicesOfferedLabel: "उपलब्ध सेवा",
      distanceKmLabel: "अंतर",
      lowBandwidthMode: "कमी बँडविड्थ मोड",
      walkthroughBtn: "⚡ थेट प्रात्यक्षिक (निमगाव/B)",
      resetDataBtn: "डेटा पूर्ववत करा",
      pinResolving: "टपाल पिन कोड एपीआय वरून माहिती मिळवत आहे...",
      pinResolved: "सत्यापित टपाल क्षेत्र",
      pinNoCampsNearby: "या पिन कोडमध्ये सध्या कोणतेही शिबिर नियोजित नाही. जिल्ह्यातील इतर शासकीय रुग्णालये आणि शिबिरे उपलब्ध आहेत.",
      requestCampInPin: "या पिन कोडसाठी आरोग्य शिबिराची मागणी करा",
      postalApiTag: "भारतीय डाक API प्रमाणित",
      navRegister: "केंद्रासाठी नोंदणी",
      registerTitle: "जवळच्या आरोग्य केंद्रासाठी नागरिक नोंदणी",
      registerDesc: "आपल्या जवळच्या प्राथमिक आरोग्य केंद्र (PHC), रुग्णालय किंवा आरोग्य शिबिराला भेट देण्यासाठी नावनोंदणी करा आणि स्वागत कक्षात दाखवण्यासाठी अधिकृत डिजिटल टोकन पास मिळवा.",
      registerTabNew: "भेट नोंदवा",
      registerTabPasses: "माझे नोंदणीकृत पास",
      btnBookVisit: "भेट नोंदवा आणि टोकन पास मिळवा",
      visitPassTitle: "अधिकृत डिजिटल भेट टोकन",
      tokenNumLabel: "टोकन क्रमांक",
      patientNameLabel: "नागरिकाचे नाव",
      ageGenderLabel: "वय / लिंग",
      contactPhoneLabel: "मोबाईल क्रमांक",
      centerSelectedLabel: "निवडलेले आरोग्य केंद्र",
      serviceNeededLabel: "आवश्यक वैद्यकीय सेवा",
      visitDateSlotLabel: "तारीख आणि वेळ स्लॉट"
    }
  };

  // --- Storage Key (bumped to refresh with user registration system) ---
  const STORAGE_KEY = "swasthya_connect_store_v6";

  // App Global State
  const state = {
    currentLang: 'en',
    currentTab: 'home',
    searchQuery: '',
    pincodeInfo: null, // { pincode, district, block, state, postOffices, isResolving, source }
    isSearchingPin: false,
    selectedCampFilter: 'all',
    selectedServiceFilter: 'all',
    selectedFacilityTypeFilter: 'all',
    selectedPriorityFilter: 'all',
    selectedRegisterTab: 'book', // 'book' or 'passes'
    preselectedCenterId: null,
    preselectedCenterType: null, // 'facility' or 'camp'
    activeModal: null,
    modalData: null,
    lowBandwidth: false,
    toastMessage: null,
    communities: [],
    facilities: [],
    camps: [],
    education: [],
    reminders: [],
    registrations: [],
    mapInstance: null,
    mapMarkers: [],
    charts: {}
  };

  // --- Helper: Translation Getter ---
  function t(key) {
    const langDict = i18n[state.currentLang] || i18n.en;
    return langDict[key] || i18n.en[key] || key;
  }

  // --- Notification Toast ---
  function showToast(message, type = 'info') {
    const toast = document.getElementById('toast-container');
    if (!toast) return;
    toast.innerHTML = `
      <div class="px-4 py-3 rounded-lg shadow-lg border text-sm flex items-center gap-2 transform transition-all duration-300 ${
        type === 'success' ? 'bg-emerald-50 border-emerald-300 text-emerald-800' :
        type === 'warning' ? 'bg-amber-50 border-amber-300 text-amber-800' :
        'bg-sky-50 border-sky-300 text-sky-800'
      }">
        <span class="font-bold">${type === 'success' ? '✓' : 'ℹ'}</span>
        <span>${message}</span>
      </div>
    `;
    toast.classList.remove('hidden');
    clearTimeout(toast._timeout);
    toast._timeout = setTimeout(() => {
      toast.classList.add('hidden');
    }, 4000);
  }

  // --- India Post Postal PIN Code API Service & Offline Cache ---
  const PIN_CACHE = {
    "413120": { district: "Pune", block: "Indapur", state: "Maharashtra", postOffices: ["Nimgaon Ketki", "Indapur", "Ghotondi", "Kati", "Varkute KH"] },
    "412207": { district: "Pune", block: "Haveli", state: "Maharashtra", postOffices: ["Koregaon Wadi", "Koregaon Mul", "Loni Kalbhor"] },
    "412802": { district: "Satara", block: "Khandala", state: "Maharashtra", postOffices: ["Ambegaon Khurd", "Shirwal", "Khandala"] },
    "410505": { district: "Pune", block: "Khed", state: "Maharashtra", postOffices: ["Bhimashankar Wadi", "Rajgurunagar", "Chakan"] },
    "411015": { district: "Pune", block: "Pune City", state: "Maharashtra", postOffices: ["Dhanori", "Tingre Nagar", "Vishrantwadi"] },
    "412205": { district: "Pune", block: "Bhor", state: "Maharashtra", postOffices: ["Shivapur Tola", "Khed Shivapur", "Nasrapur"] },
    "410502": { district: "Pune", block: "Junnar", state: "Maharashtra", postOffices: ["Junnar Bagait", "Junnar", "Otur"] },
    "412108": { district: "Pune", block: "Mulshi", state: "Maharashtra", postOffices: ["Mulshi Paud Pada", "Paud", "Pirangut"] },
    "411028": { district: "Pune", block: "Haveli", state: "Maharashtra", postOffices: ["Hadapsar", "Gadital", "Sasane Nagar"] },
    "412803": { district: "Satara", block: "Wai", state: "Maharashtra", postOffices: ["Wai", "Panchgani Road", "Bhuinj"] },
    "411001": { district: "Pune", block: "Pune City", state: "Maharashtra", postOffices: ["Pune GPO", "Camp", "Pune Station"] },
    "400001": { district: "Mumbai", block: "Mumbai", state: "Maharashtra", postOffices: ["Mumbai GPO", "Fort", "Colaba"] },
    "110001": { district: "Central Delhi", block: "New Delhi", state: "Delhi", postOffices: ["Connaught Place", "Barakhamba Road"] }
  };

  /**
   * Resolves ANY Indian 6-digit PIN code via the official India Post Postal Directory API
   * (with built-in local cache and fallback for 100% offline reliability)
   */
  async function resolvePostalPincode(pincode) {
    if (!/^\d{6}$/.test(pincode)) return null;

    // Check fast cache first
    if (PIN_CACHE[pincode]) {
      return {
        pincode,
        ...PIN_CACHE[pincode],
        source: 'Verified Local Directory Cache'
      };
    }

    // Call live India Post API with timeout
    try {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 4000);

      const res = await fetch(`https://api.postalpincode.in/pincode/${pincode}`, {
        signal: controller.signal
      });
      clearTimeout(timeoutId);

      if (!res.ok) throw new Error("HTTP " + res.status);
      const data = await res.json();

      if (Array.isArray(data) && data[0] && data[0].Status === "Success" && data[0].PostOffice && data[0].PostOffice.length > 0) {
        const poList = data[0].PostOffice;
        const primary = poList[0];
        const postOffices = [...new Set(poList.map(p => p.Name))];
        const result = {
          pincode,
          district: primary.District || "District",
          block: primary.Block || primary.Taluk || primary.Division || "Taluka",
          state: primary.State || "India",
          postOffices,
          source: 'Live India Post API'
        };
        PIN_CACHE[pincode] = result;
        return result;
      }
    } catch (err) {
      console.warn("Live postal PIN API lookup error:", err);
    }

    // Fallback if network fails
    return {
      pincode,
      district: pincode.startsWith("41") ? "Maharashtra Region" : "India Region",
      block: "Postal Zone",
      state: pincode.startsWith("4") ? "Maharashtra" : "India",
      postOffices: [`Postal Area (${pincode})`],
      source: 'Postal Code Directory'
    };
  }

  /**
   * Unified Search Handler: handles PIN codes, city/village names, and keywords
   */
  async function executeSearch(query, targetTab = 'camps') {
    const trimmed = (query || '').trim();
    state.searchQuery = trimmed;

    // Check if query is or contains a 6-digit PIN code
    const pinMatch = trimmed.match(/\b\d{6}\b/);
    if (pinMatch) {
      const pin = pinMatch[0];
      state.isSearchingPin = true;
      state.pincodeInfo = { pincode: pin, isResolving: true };

      if (state.currentTab !== targetTab) {
        navigateTo(targetTab);
      } else {
        renderApp();
      }

      showToast(`Resolving PIN ${pin} via India Post Directory API...`, "info");
      const info = await resolvePostalPincode(pin);
      state.isSearchingPin = false;
      state.pincodeInfo = info;
      showToast(`📍 Found: ${info.postOffices[0] || 'Postal Zone'}, ${info.district} (${info.state})`, "success");
      renderApp();
      return;
    }

    // Check if query matches a known village or district in our sample data
    state.pincodeInfo = null;
    state.isSearchingPin = false;

    // If query matches a community, check its PIN code
    const matchingComm = state.communities.find(c =>
      c.area_name.toLowerCase().includes(trimmed.toLowerCase()) ||
      c.district.toLowerCase().includes(trimmed.toLowerCase())
    );
    if (matchingComm && matchingComm.pincode && trimmed.length >= 3) {
      const info = await resolvePostalPincode(matchingComm.pincode);
      state.pincodeInfo = info;
    }

    if (state.currentTab !== targetTab) {
      navigateTo(targetTab);
    } else {
      renderApp();
    }
  }

  // --- Core Algorithm: Transparent Rule-Based Gap Analysis Engine ---
  function analyzeHealthcareGaps(communities, facilities, camps) {
    return communities.map(community => {
      const population = Number(community.population) || 1;
      const screened = Number(community.people_screened) || 0;
      const coveragePercent = Number(((screened / population) * 100).toFixed(1));
      const distanceKm = Number(community.nearest_facility_km) || 0;
      const recentCamps = Number(community.recent_camps_count) || 0;

      let priority = 'low';
      let priorityLabel = 'Lower Priority (Baseline Outreach)';
      let badgeClass = 'bg-emerald-100 text-emerald-800 border-emerald-300';
      let reasons = [];
      let recommendation = '';

      // High Priority: Low screening coverage (< 20%) AND (distance > 5km OR recent camps == 0)
      if (coveragePercent < 20 && (distanceKm > 5 || recentCamps === 0)) {
        priority = 'high';
        priorityLabel = 'High Priority (Urgent Outreach)';
        badgeClass = 'bg-rose-100 text-rose-800 border-rose-300';
        reasons.push(`Low screening coverage (${coveragePercent}% vs 20% benchmark)`);
        if (distanceKm > 5) reasons.push(`High travel barrier to nearest facility (${distanceKm} km)`);
        if (recentCamps === 0) reasons.push(`Zero recent outreach health camps`);
        recommendation = `Priority candidate for dedicated mobile screening camp & ASHA outreach drive.`;
      }
      // Medium Priority: Low screening coverage (< 20%) but facility nearby, OR coverage 20-35% with long travel distance
      else if (coveragePercent < 20 && distanceKm <= 5) {
        priority = 'medium';
        priorityLabel = 'Medium Priority (Investigate Access)';
        badgeClass = 'bg-amber-100 text-amber-800 border-amber-300';
        reasons.push(`Low screening coverage (${coveragePercent}%) despite nearby facility (${distanceKm} km)`);
        reasons.push(`Potential awareness or weekday timing barrier`);
        recommendation = `Investigate non-distance barriers (service timings, awareness, or transportation).`;
      } else if (coveragePercent >= 20 && coveragePercent < 35 && distanceKm > 5) {
        priority = 'medium';
        priorityLabel = 'Medium Priority (Geographic Vulnerability)';
        badgeClass = 'bg-amber-100 text-amber-800 border-amber-300';
        reasons.push(`Moderate coverage (${coveragePercent}%) with remote facility access (${distanceKm} km)`);
        recommendation = `Conduct seasonal follow-up camp to maintain preventive care.`;
      }
      // Low Priority: Higher screening coverage (>= 35%) and reasonable service availability
      else {
        priority = 'low';
        priorityLabel = 'Lower Priority (Reasonable Service)';
        badgeClass = 'bg-emerald-100 text-emerald-800 border-emerald-300';
        reasons.push(`Healthy screening coverage (${coveragePercent}%)`);
        reasons.push(`Reasonable access to facility within ${distanceKm} km`);
        recommendation = `Maintain standard periodic monitoring and routine Sub-Centre OPD.`;
      }

      // Link nearest facility details
      const nearestFacility = facilities.find(f => f.facility_id === community.nearest_facility_id);

      // Check upcoming camps in this area
      const upcomingCamps = camps.filter(c => c.area_id === community.area_id && c.status === 'upcoming');

      return {
        ...community,
        coveragePercent,
        priority,
        priorityLabel,
        badgeClass,
        reasons,
        recommendation,
        nearestFacility,
        upcomingCampsCount: upcomingCamps.length
      };
    });
  }

  // --- Sample Default Registrations for Instant Demonstration ---
  function getDefaultRegistrations() {
    return [
      {
        id: "REG-1001",
        token_number: "SC-4131-01",
        patient_name: "Ramesh Pawar",
        age: 48,
        gender: "Male",
        phone: "+91 98221 44021",
        pincode: "413120",
        locality: "Nimgaon Ketki, Indapur",
        center_type: "facility",
        center_id: "F02",
        center_name: "Indapur Sub-District Hospital",
        center_address: "National Highway 65, Indapur, Pune - 413120",
        center_phone: "+91 2111 223400",
        center_distance_km: 8.5,
        service_needed: "Hypertension / BP Screening & Medication Refill",
        visit_date: "2026-10-21",
        time_slot: "09:00 AM - 12:00 PM (Morning)",
        notes: "Mild dizziness in morning, previous BP prescription available",
        status: "confirmed",
        created_at: new Date().toISOString()
      },
      {
        id: "REG-1002",
        token_number: "SC-4122-02",
        patient_name: "Sunita Shinde",
        age: 29,
        gender: "Female",
        phone: "+91 94220 88912",
        pincode: "412207",
        locality: "Koregaon Wadi, Haveli",
        center_type: "facility",
        center_id: "F01",
        center_name: "Koregaon Mul Primary Health Centre (PHC)",
        center_address: "Main Road, Koregaon Mul, Haveli, Pune - 412207",
        center_phone: "+91 20 2711 0244",
        center_distance_km: 1.2,
        service_needed: "Maternal & Antenatal Checkup (ANC)",
        visit_date: "2026-10-22",
        time_slot: "10:00 AM - 01:00 PM",
        notes: "Routine 2nd trimester antenatal checkup & iron supplements",
        status: "confirmed",
        created_at: new Date().toISOString()
      },
      {
        id: "REG-1003",
        token_number: "SC-4131-03",
        patient_name: "Vikas Jagtap",
        age: 54,
        gender: "Male",
        phone: "+91 97665 33190",
        pincode: "413120",
        locality: "Village B (Nimgaon Ketki)",
        center_type: "camp",
        center_id: "C01",
        center_name: "Village B Community Health & BP Screening Camp",
        center_address: "Zilla Parishad Community Hall, Nimgaon Ketki, Indapur",
        center_phone: "+91 98220 11982",
        center_distance_km: 0.5,
        service_needed: "Blood Pressure & Diabetes Checkup",
        visit_date: "2026-11-10",
        time_slot: "09:00 AM - 12:00 PM (Morning)",
        notes: "Family history of diabetes; requested blood sugar test",
        status: "confirmed",
        created_at: new Date().toISOString()
      }
    ];
  }

  // --- Data Persistence Layer ---
  async function loadInitialData() {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (saved) {
      try {
        const parsed = JSON.parse(saved);
        state.communities = parsed.communities || [];
        state.facilities = parsed.facilities || [];
        state.camps = parsed.camps || [];
        state.education = parsed.education || [];
        state.reminders = parsed.reminders || [];
        state.registrations = (parsed.registrations && parsed.registrations.length > 0) ? parsed.registrations : getDefaultRegistrations();
        return;
      } catch (e) {
        console.warn("Failed to load saved state, falling back to files", e);
      }
    }

    // Load fresh JSON files
    try {
      const [comRes, facRes, campRes, eduRes] = await Promise.all([
        fetch('data/communities.json'),
        fetch('data/facilities.json'),
        fetch('data/camps.json'),
        fetch('data/education.json')
      ]);

      state.communities = await comRes.json();
      state.facilities = await facRes.json();
      state.camps = await campRes.json();
      state.education = await eduRes.json();
      state.registrations = getDefaultRegistrations();
      saveState();
    } catch (err) {
      console.error("Error loading JSON datasets", err);
    }
  }

  function saveState() {
    const payload = {
      communities: state.communities,
      facilities: state.facilities,
      camps: state.camps,
      education: state.education,
      reminders: state.reminders,
      registrations: state.registrations
    };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
  }

  function resetState() {
    localStorage.removeItem(STORAGE_KEY);
    state.searchQuery = '';
    state.pincodeInfo = null;
    loadInitialData().then(() => {
      showToast("Data reset to initial prototype state.", "info");
      renderApp();
    });
  }

  // --- User Registration & Clinic Visit Booking Handlers ---
  function registerUserVisit(regData) {
    const tokenSuffix = Math.floor(10 + Math.random() * 90);
    const pinPart = (regData.pincode && regData.pincode.length >= 4) ? regData.pincode.slice(0, 4) : '2026';
    const tokenNumber = `SC-${pinPart}-${tokenSuffix}`;

    const newRecord = {
      id: "REG-" + Date.now(),
      token_number: tokenNumber,
      patient_name: regData.patient_name || 'Resident',
      age: parseInt(regData.age, 10) || 30,
      gender: regData.gender || 'Not specified',
      phone: regData.phone || '+91 98XXX XXXXX',
      pincode: regData.pincode || '',
      locality: regData.locality || '',
      center_type: regData.center_type || 'facility',
      center_id: regData.center_id || '',
      center_name: regData.center_name || 'Public Healthcare Centre',
      center_address: regData.center_address || 'District Health Facility',
      center_phone: regData.center_phone || '+91 20 2612 0000',
      center_distance_km: regData.center_distance_km || 2.5,
      service_needed: regData.service_needed || 'General OPD Consultation',
      visit_date: regData.visit_date || new Date().toISOString().split('T')[0],
      time_slot: regData.time_slot || '09:00 AM - 12:00 PM (Morning)',
      notes: regData.notes || '',
      status: 'confirmed',
      created_at: new Date().toISOString()
    };

    state.registrations.unshift(newRecord);
    saveState();
    showToast(`Visit booked! Token #${newRecord.token_number} generated for ${newRecord.center_name}`, "success");
    
    // Automatically open the official Visit Pass modal
    openVisitPassModal(newRecord.id);
    renderApp();
    return newRecord;
  }

  function markRegistrationVisited(regId) {
    const reg = state.registrations.find(r => r.id === regId);
    if (!reg) return false;

    reg.status = 'visited';
    reg.visited_at = new Date().toISOString();

    // Increment screening count for the community if identifiable
    let comm = null;
    if (reg.pincode) {
      comm = state.communities.find(c => c.pincode === reg.pincode);
    }
    if (!comm && reg.locality) {
      comm = state.communities.find(c => reg.locality.toLowerCase().includes(c.area_name.toLowerCase()));
    }
    if (!comm && reg.center_type === 'camp') {
      const camp = state.camps.find(c => c.camp_id === reg.center_id);
      if (camp) comm = state.communities.find(c => c.area_id === camp.area_id);
    }

    if (comm) {
      comm.people_screened = (comm.people_screened || 0) + 1;
      saveState();
      showToast(`Check-in confirmed for ${reg.patient_name}! ${comm.area_name} screened count updated to ${comm.people_screened}.`, "success");
    } else {
      saveState();
      showToast(`Check-in confirmed for ${reg.patient_name} at ${reg.center_name}!`, "success");
    }

    renderApp();
    return true;
  }

  function cancelRegistration(regId) {
    const reg = state.registrations.find(r => r.id === regId);
    if (!reg) return false;
    reg.status = 'cancelled';
    saveState();
    showToast(`Visit pass ${reg.token_number} cancelled.`, "info");
    renderApp();
    return true;
  }

  function openRegisterWithCenter(centerId, centerType = 'facility') {
    state.preselectedCenterId = centerId;
    state.preselectedCenterType = centerType;
    state.selectedRegisterTab = 'book';
    navigateTo('register');
  }

  function openVisitPassModal(regId) {
    const reg = state.registrations.find(r => r.id === regId);
    if (!reg) return;
    state.activeModal = 'visit_pass';
    state.modalData = reg;
    renderModal();
  }

  // --- Closed-Loop Outreach Tracking: Record Attendance ---
  function recordCampAttendance(campId, attendanceCount) {
    const camp = state.camps.find(c => c.camp_id === campId);
    if (!camp) return false;

    const count = parseInt(attendanceCount, 10);
    if (isNaN(count) || count <= 0) return false;

    camp.attendance_recorded = count;
    camp.status = 'completed';

    // Update community screened total
    const comm = state.communities.find(c => c.area_id === camp.area_id);
    if (comm) {
      const prevScreened = comm.people_screened;
      comm.people_screened = prevScreened + count;
      comm.recent_camps_count = (comm.recent_camps_count || 0) + 1;
      comm.last_camp_date = new Date().toISOString().split('T')[0];

      saveState();
      showToast(
        `Attendance recorded! ${comm.area_name}: Screened increased from ${prevScreened} to ${comm.people_screened} (${((comm.people_screened/comm.population)*100).toFixed(1)}% coverage)`,
        "success"
      );
    } else {
      saveState();
      showToast(`Attendance recorded for ${camp.name}`, "success");
    }

    renderApp();
    return true;
  }

  // --- Add New Camp (Outreach Scheduling) ---
  function addNewCamp(campData) {
    state.camps.unshift(campData);
    saveState();
    showToast(`New health camp scheduled: "${campData.name}"`, "success");
    renderApp();
  }

  // --- Register Interest / Screening Reminder ---
  function registerReminder(campId, phoneOrEmail, serviceType) {
    const camp = state.camps.find(c => c.camp_id === campId);
    const reminder = {
      id: "REM-" + Date.now(),
      camp_id: campId,
      camp_name: camp ? camp.name : "Health Screening",
      area_name: camp ? camp.area_name : "Locality",
      date: camp ? camp.date : "Upcoming",
      contact: phoneOrEmail,
      service: serviceType || "General Checkup",
      timestamp: new Date().toLocaleString()
    };
    state.reminders.unshift(reminder);
    saveState();
    showToast(`Reminder registered for ${reminder.camp_name}! (Privacy safe: no health history stored)`, "success");
    renderApp();
  }

  // --- Navigation Router ---
  function navigateTo(tabName) {
    state.currentTab = tabName;
    window.scrollTo({ top: 0, behavior: 'smooth' });
    renderApp();
  }

  // --- Render Layout & Views ---
  function renderApp() {
    renderHeader();
    renderMainContent();
    renderFooter();
    renderModal();
    if (window.lucide) window.lucide.createIcons();
  }

  function renderHeader() {
    const header = document.getElementById('app-header');
    if (!header) return;

    header.innerHTML = `
      <!-- Safety / Prototype Disclaimer Banner -->
      <div class="bg-amber-500 text-amber-950 px-4 py-1.5 text-xs font-medium flex flex-wrap items-center justify-between border-b border-amber-600/30">
        <div class="flex items-center gap-2">
          <span class="inline-block w-2 h-2 rounded-full bg-amber-900 animate-pulse"></span>
          <span><strong>${t('demoBadge')}</strong>: ${t('demoSubtitle')}</span>
        </div>
        <div class="flex items-center gap-3">
          <button id="btn-walkthrough" class="bg-amber-950 hover:bg-black text-amber-200 px-2 py-0.5 rounded text-xs font-semibold tracking-wide transition flex items-center gap-1 shadow-sm">
            <span>⚡</span> ${t('walkthroughBtn')}
          </button>
          <button id="btn-reset-data" class="hover:underline text-amber-950 font-medium">
            ${t('resetDataBtn')}
          </button>
        </div>
      </div>

      <!-- Main Navigation Bar -->
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 flex flex-wrap items-center justify-between gap-4">
        <div class="flex items-center gap-3 cursor-pointer" id="nav-brand">
          <div class="w-10 h-10 rounded-xl bg-gradient-to-tr from-sky-600 to-teal-500 flex items-center justify-center text-white shadow-md shadow-sky-500/20 font-bold text-xl">
            ✚
          </div>
          <div>
            <div class="font-extrabold text-xl tracking-tight text-slate-900 flex items-center gap-2">
              <span>${t('appName')}</span>
              <span class="text-xs font-semibold px-2 py-0.5 rounded-full bg-sky-100 text-sky-800 border border-sky-200">v2.0 API</span>
            </div>
            <div class="text-xs text-slate-500 font-medium">${t('appTagline')}</div>
          </div>
        </div>

        <!-- Desktop Navigation Tabs -->
        <nav class="hidden md:flex items-center gap-1 bg-slate-100 p-1 rounded-xl border border-slate-200 text-sm font-medium text-slate-600">
          <button class="nav-tab px-3.5 py-1.5 rounded-lg transition ${state.currentTab === 'home' ? 'bg-white text-sky-700 shadow-sm font-semibold' : 'hover:text-slate-900'}" data-tab="home">
            ${t('navHome')}
          </button>
          <button class="nav-tab px-3.5 py-1.5 rounded-lg transition ${state.currentTab === 'dashboard' ? 'bg-white text-sky-700 shadow-sm font-semibold' : 'hover:text-slate-900'}" data-tab="dashboard">
            ${t('navDashboard')}
          </button>
          <button class="nav-tab px-3.5 py-1.5 rounded-lg transition ${state.currentTab === 'camps' ? 'bg-white text-sky-700 shadow-sm font-semibold' : 'hover:text-slate-900'}" data-tab="camps">
            ${t('navCamps')}
          </button>
          <button class="nav-tab px-3.5 py-1.5 rounded-lg transition ${state.currentTab === 'facilities' ? 'bg-white text-sky-700 shadow-sm font-semibold' : 'hover:text-slate-900'}" data-tab="facilities">
            ${t('navFacilities')}
          </button>
          <button class="nav-tab px-3.5 py-1.5 rounded-lg transition ${state.currentTab === 'register' ? 'bg-white text-emerald-700 shadow-sm font-semibold' : 'hover:text-slate-900'}" data-tab="register">
            ${t('navRegister')} <span class="text-[10px] bg-emerald-100 text-emerald-800 font-bold px-1.5 py-0.5 rounded ml-1">Visit Pass</span>
          </button>
          <button class="nav-tab px-3.5 py-1.5 rounded-lg transition ${state.currentTab === 'map' ? 'bg-white text-sky-700 shadow-sm font-semibold' : 'hover:text-slate-900'}" data-tab="map">
            ${t('navMap')}
          </button>
          <button class="nav-tab px-3.5 py-1.5 rounded-lg transition ${state.currentTab === 'education' ? 'bg-white text-sky-700 shadow-sm font-semibold' : 'hover:text-slate-900'}" data-tab="education">
            ${t('navEducation')}
          </button>
          <button class="nav-tab px-3.5 py-1.5 rounded-lg transition ${state.currentTab === 'admin' ? 'bg-white text-sky-700 shadow-sm font-semibold' : 'hover:text-slate-900'}" data-tab="admin">
            ${t('navAdmin')}
          </button>
        </nav>

        <!-- Right Controls: Language Selector & Accessibility -->
        <div class="flex items-center gap-2">
          <!-- Language Toggle -->
          <div class="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200 text-xs font-semibold">
            <button class="lang-btn px-2 py-1 rounded ${state.currentLang === 'en' ? 'bg-white text-sky-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'}" data-lang="en">EN</button>
            <button class="lang-btn px-2 py-1 rounded ${state.currentLang === 'hi' ? 'bg-white text-sky-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'}" data-lang="hi">हिन्दी</button>
            <button class="lang-btn px-2 py-1 rounded ${state.currentLang === 'mr' ? 'bg-white text-sky-700 shadow-xs' : 'text-slate-600 hover:text-slate-900'}" data-lang="mr">मराठी</button>
          </div>

          <!-- Low Bandwidth Toggle -->
          <button id="toggle-low-bandwidth" title="${t('lowBandwidthMode')}" class="p-2 rounded-lg border text-xs flex items-center gap-1 transition ${state.lowBandwidth ? 'bg-slate-900 text-white border-slate-900' : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'}">
            <span class="text-sm">📶</span>
            <span class="hidden sm:inline">${state.lowBandwidth ? 'Lite' : 'Standard'}</span>
          </button>
        </div>
      </div>

      <!-- Mobile Navigation Sub-bar -->
      <div class="md:hidden flex overflow-x-auto gap-2 px-4 py-2 bg-slate-50 border-t border-slate-200 text-xs font-medium no-scrollbar">
        <button class="nav-tab whitespace-nowrap px-3 py-1 rounded-full ${state.currentTab === 'home' ? 'bg-sky-600 text-white' : 'bg-white text-slate-700 border border-slate-200'}" data-tab="home">${t('navHome')}</button>
        <button class="nav-tab whitespace-nowrap px-3 py-1 rounded-full ${state.currentTab === 'dashboard' ? 'bg-sky-600 text-white' : 'bg-white text-slate-700 border border-slate-200'}" data-tab="dashboard">${t('navDashboard')}</button>
        <button class="nav-tab whitespace-nowrap px-3 py-1 rounded-full ${state.currentTab === 'camps' ? 'bg-sky-600 text-white' : 'bg-white text-slate-700 border border-slate-200'}" data-tab="camps">${t('navCamps')}</button>
        <button class="nav-tab whitespace-nowrap px-3 py-1 rounded-full ${state.currentTab === 'facilities' ? 'bg-sky-600 text-white' : 'bg-white text-slate-700 border border-slate-200'}" data-tab="facilities">${t('navFacilities')}</button>
        <button class="nav-tab whitespace-nowrap px-3 py-1 rounded-full ${state.currentTab === 'register' ? 'bg-emerald-600 text-white' : 'bg-white text-slate-700 border border-slate-200'}" data-tab="register">🎫 ${t('navRegister')}</button>
        <button class="nav-tab whitespace-nowrap px-3 py-1 rounded-full ${state.currentTab === 'map' ? 'bg-sky-600 text-white' : 'bg-white text-slate-700 border border-slate-200'}" data-tab="map">${t('navMap')}</button>
        <button class="nav-tab whitespace-nowrap px-3 py-1 rounded-full ${state.currentTab === 'education' ? 'bg-sky-600 text-white' : 'bg-white text-slate-700 border border-slate-200'}" data-tab="education">${t('navEducation')}</button>
        <button class="nav-tab whitespace-nowrap px-3 py-1 rounded-full ${state.currentTab === 'admin' ? 'bg-sky-600 text-white' : 'bg-white text-slate-700 border border-slate-200'}" data-tab="admin">${t('navAdmin')}</button>
      </div>
    `;

    // Attach Event Handlers
    document.getElementById('nav-brand').onclick = () => navigateTo('home');
    document.querySelectorAll('.nav-tab').forEach(b => {
      b.onclick = () => navigateTo(b.dataset.tab);
    });
    document.querySelectorAll('.lang-btn').forEach(b => {
      b.onclick = () => {
        state.currentLang = b.dataset.lang;
        renderApp();
      };
    });
    document.getElementById('toggle-low-bandwidth').onclick = () => {
      state.lowBandwidth = !state.lowBandwidth;
      document.body.classList.toggle('low-bandwidth', state.lowBandwidth);
      renderApp();
    };
    document.getElementById('btn-reset-data').onclick = resetState;
    document.getElementById('btn-walkthrough').onclick = openWalkthroughModal;
  }

  function renderMainContent() {
    const main = document.getElementById('app-main');
    if (!main) return;

    switch (state.currentTab) {
      case 'home':
        renderHome(main);
        break;
      case 'dashboard':
        renderDashboard(main);
        break;
      case 'camps':
        renderCamps(main);
        break;
      case 'facilities':
        renderFacilities(main);
        break;
      case 'register':
        renderRegister(main);
        break;
      case 'map':
        renderMap(main);
        break;
      case 'education':
        renderEducation(main);
        break;
      case 'admin':
        renderAdmin(main);
        break;
      default:
        renderHome(main);
    }
  }

  // --- View: Home Page ---
  function renderHome(container) {
    const analyzed = analyzeHealthcareGaps(state.communities, state.facilities, state.camps);
    const highPriorityCount = analyzed.filter(a => a.priority === 'high').length;
    const upcomingCampsCount = state.camps.filter(c => c.status === 'upcoming').length;
    const totalScreened = state.communities.reduce((acc, c) => acc + (c.people_screened || 0), 0);
    const totalPopulation = state.communities.reduce((acc, c) => acc + (c.population || 0), 0);
    const avgCoverage = ((totalScreened / totalPopulation) * 100).toFixed(1);

    container.innerHTML = `
      <div class="space-y-8 py-6">
        <!-- Hero Section -->
        <div class="relative overflow-hidden rounded-3xl bg-gradient-to-br from-sky-900 via-sky-800 to-teal-900 text-white p-6 sm:p-10 shadow-xl border border-sky-700/50">
          <div class="max-w-3xl space-y-4 relative z-10">
            <div class="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-sky-500/20 text-sky-200 text-xs font-semibold backdrop-blur-md border border-sky-400/30">
              <span>🏥</span> Maharashtra Rural &amp; Semi-Urban Healthcare Access Initiative
            </div>
            <h1 class="text-3xl sm:text-5xl font-extrabold tracking-tight leading-tight">
              ${t('heroTitle')}
            </h1>
            <p class="text-sky-100 text-sm sm:text-base leading-relaxed">
              ${t('heroDesc')}
            </p>

            <!-- Prominent Responsive PIN / Locality Search Bar -->
            <div class="pt-2">
              <div class="bg-white p-2 rounded-2xl shadow-xl flex flex-col sm:flex-row gap-2 border border-slate-100">
                <div class="flex-1 flex items-center px-3 gap-2">
                  <span class="text-sky-600 text-lg">📮</span>
                  <input type="text" id="home-search-input" value="${state.searchQuery}" placeholder="${t('quickSearchPlaceholder')}" class="w-full text-slate-800 placeholder-slate-400 text-sm focus:outline-none py-2 font-normal" />
                </div>
                <button id="home-search-btn" class="bg-sky-600 hover:bg-sky-700 text-white px-6 py-2.5 rounded-xl font-semibold text-sm transition shadow-md flex items-center justify-center gap-2">
                  <span>${t('searchBtn')}</span>
                </button>
              </div>

              <!-- Quick PIN & City Search Chips -->
              <div class="flex flex-wrap gap-2 mt-3 text-xs text-sky-200 items-center">
                <span class="font-medium text-sky-300">Popular PINs &amp; Villages:</span>
                <button class="quick-chip bg-sky-800/80 hover:bg-sky-700 px-2.5 py-1 rounded-lg border border-sky-600/50" data-query="413120">PIN 413120 (Village B - Nimgaon)</button>
                <button class="quick-chip bg-sky-800/80 hover:bg-sky-700 px-2.5 py-1 rounded-lg border border-sky-600/50" data-query="412207">PIN 412207 (Village A - Koregaon)</button>
                <button class="quick-chip bg-sky-800/80 hover:bg-sky-700 px-2.5 py-1 rounded-lg border border-sky-600/50" data-query="412802">PIN 412802 (Village D - Ambegaon)</button>
                <button class="quick-chip bg-sky-800/80 hover:bg-sky-700 px-2.5 py-1 rounded-lg border border-sky-600/50" data-query="411015">PIN 411015 (Dhanori Urban)</button>
                <button class="quick-chip bg-sky-800/80 hover:bg-sky-700 px-2.5 py-1 rounded-lg border border-sky-600/50" data-query="411001">PIN 411001 (Pune City GPO)</button>
              </div>
            </div>

            <!-- Hero Action Buttons -->
            <div class="flex flex-wrap gap-3 pt-3">
              <button class="nav-shortcut bg-emerald-500 hover:bg-emerald-600 text-white px-5 py-2.5 rounded-xl text-sm font-bold shadow-md transition flex items-center gap-2" data-target="register">
                <span>🎫</span> ${t('navRegister')} (Nearest Centre)
              </button>
              <button class="nav-shortcut bg-white text-sky-900 hover:bg-sky-50 px-5 py-2.5 rounded-xl text-sm font-bold shadow-md transition flex items-center gap-2" data-target="camps">
                <span>🏕️</span> ${t('findCampsBtn')}
              </button>
              <button class="nav-shortcut bg-teal-500/30 hover:bg-teal-500/40 text-white border border-teal-400/40 px-5 py-2.5 rounded-xl text-sm font-semibold transition backdrop-blur-sm flex items-center gap-2" data-target="dashboard">
                <span>📊</span> ${t('viewDashboardBtn')}
              </button>
            </div>
          </div>
        </div>

        <!-- Real-Time Metrics & Highlights -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div class="text-xs font-semibold text-slate-500 uppercase tracking-wider">${t('totalCommunities')}</div>
            <div class="mt-2 text-3xl font-black text-slate-900">${state.communities.length}</div>
            <div class="mt-1 text-xs text-slate-500">Pop: ${totalPopulation.toLocaleString()} monitored</div>
          </div>

          <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div class="text-xs font-semibold text-slate-500 uppercase tracking-wider">${t('totalCamps')}</div>
            <div class="mt-2 text-3xl font-black text-emerald-600">${state.camps.length}</div>
            <div class="mt-1 text-xs text-emerald-700 font-medium">${upcomingCampsCount} active / upcoming</div>
          </div>

          <div class="bg-white p-5 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between">
            <div class="text-xs font-semibold text-slate-500 uppercase tracking-wider">${t('totalFacilities')}</div>
            <div class="mt-2 text-3xl font-black text-sky-600">${state.facilities.length}</div>
            <div class="mt-1 text-xs text-slate-500">PHCs, CHCs &amp; Hospitals</div>
          </div>

          <div class="bg-white p-5 rounded-2xl border border-rose-200 shadow-xs flex flex-col justify-between bg-rose-50/40">
            <div class="text-xs font-semibold text-rose-700 uppercase tracking-wider">${t('underservedAreas')}</div>
            <div class="mt-2 text-3xl font-black text-rose-600">${highPriorityCount}</div>
            <div class="mt-1 text-xs text-rose-700 font-medium">Coverage &lt;20% &amp; Remote</div>
          </div>
        </div>

        <!-- Three Pillars Feature Callout (Part A, Part B & Part C) -->
        <div class="grid lg:grid-cols-3 gap-6">
          <!-- Part A Card -->
          <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
            <div class="space-y-3">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-rose-100 text-rose-700 flex items-center justify-center font-bold text-lg">
                  A
                </div>
                <div>
                  <h3 class="font-bold text-slate-900 text-base">Part A: Identify Gaps</h3>
                  <p class="text-xs text-slate-500">Data-driven analysis of underserved areas</p>
                </div>
              </div>
              <p class="text-xs text-slate-600 leading-relaxed">
                Uses transparent rule-based metrics combining <strong>Screening Coverage</strong>, <strong>Distance to Nearest Facility</strong>, and <strong>Recent Camp Frequency</strong> to flag areas needing urgent healthcare outreach.
              </p>
              <div class="bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-[11px] text-slate-700 space-y-1 font-mono">
                <div>• Coverage = (Screened / Pop) × 100</div>
                <div>• High Priority: &lt;20% &amp; Distance &gt;5 km</div>
              </div>
            </div>
            <div>
              <button class="nav-shortcut text-sky-600 hover:text-sky-800 text-xs font-semibold flex items-center gap-1" data-target="dashboard">
                View Gap Dashboard →
              </button>
            </div>
          </div>

          <!-- Part B Card -->
          <div class="bg-white rounded-2xl p-6 border border-slate-200 shadow-sm space-y-4 flex flex-col justify-between">
            <div class="space-y-3">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-sky-100 text-sky-700 flex items-center justify-center font-bold text-lg">
                  B
                </div>
                <div>
                  <h3 class="font-bold text-slate-900 text-base">Part B: Connect People</h3>
                  <p class="text-xs text-slate-500">Discover camps, PHCs &amp; reminders</p>
                </div>
              </div>
              <p class="text-xs text-slate-600 leading-relaxed">
                Lets residents search by 6-digit PIN or village name, discover upcoming camps, locate Primary Health Centres (PHCs), and set privacy-safe reminders.
              </p>
              <div class="grid grid-cols-2 gap-1.5 text-[11px]">
                <div class="p-2 rounded bg-sky-50 text-sky-900 border font-medium">✓ Postal PIN API</div>
                <div class="p-2 rounded bg-teal-50 text-teal-900 border font-medium">✓ Facility Directory</div>
              </div>
            </div>
            <div>
              <button class="nav-shortcut text-sky-600 hover:text-sky-800 text-xs font-semibold flex items-center gap-1" data-target="camps">
                Find Camps &amp; Facilities →
              </button>
            </div>
          </div>

          <!-- Part C Card -->
          <div class="bg-white rounded-2xl p-6 border border-emerald-200 shadow-sm space-y-4 flex flex-col justify-between bg-gradient-to-b from-white to-emerald-50/20">
            <div class="space-y-3">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-lg">
                  C
                </div>
                <div>
                  <h3 class="font-bold text-slate-900 text-base">Part C: Register for Visit</h3>
                  <p class="text-xs text-slate-500">Instant digital pass for closest centre</p>
                </div>
              </div>
              <p class="text-xs text-slate-600 leading-relaxed">
                Residents pre-register to visit their closest Primary Health Centre (PHC), hospital, or outreach camp with an instant <strong>Digital Token Pass (QR Code)</strong>.
              </p>
              <div class="grid grid-cols-2 gap-1.5 text-[11px]">
                <div class="p-2 rounded bg-emerald-50 text-emerald-900 border font-medium">✓ Instant Token Slip</div>
                <div class="p-2 rounded bg-indigo-50 text-indigo-900 border font-medium">✓ Priority OPD Entry</div>
              </div>
            </div>
            <div>
              <button class="nav-shortcut text-emerald-700 hover:text-emerald-900 text-xs font-bold flex items-center gap-1" data-target="register">
                Register to Visit Centre Now →
              </button>
            </div>
          </div>
        </div>

        <!-- Interactive Demo Teaser -->
        <div class="bg-amber-50 border border-amber-200 rounded-2xl p-6 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div class="space-y-1 text-center sm:text-left">
            <div class="font-bold text-amber-900 text-base flex items-center justify-center sm:justify-start gap-2">
              <span>🎯</span> Demo Scenario: Village B Outreach Journey
            </div>
            <div class="text-xs text-amber-800 max-w-2xl leading-relaxed">
              Village B (PIN 413120) has only <strong>10% coverage</strong> and an <strong>8.5 km</strong> hospital distance. Walk through how the administrator identifies the gap, schedules a camp, and how recording attendance instantly increases coverage to 20%!
            </div>
          </div>
          <button id="home-walkthrough-btn" class="bg-amber-600 hover:bg-amber-700 text-white px-5 py-2.5 rounded-xl text-xs font-bold whitespace-nowrap shadow-md transition">
            Launch Guided Scenario Walkthrough
          </button>
        </div>
      </div>
    `;

    // Handlers
    const searchInput = document.getElementById('home-search-input');
    const searchBtn = document.getElementById('home-search-btn');
    if (searchBtn && searchInput) {
      searchBtn.onclick = () => executeSearch(searchInput.value, 'camps');
      searchInput.onkeydown = (e) => {
        if (e.key === 'Enter') executeSearch(searchInput.value, 'camps');
      };
    }

    document.querySelectorAll('.quick-chip').forEach(chip => {
      chip.onclick = () => {
        executeSearch(chip.dataset.query, 'camps');
      };
    });

    document.querySelectorAll('.nav-shortcut').forEach(b => {
      b.onclick = () => navigateTo(b.dataset.target);
    });

    const homeWalkthroughBtn = document.getElementById('home-walkthrough-btn');
    if (homeWalkthroughBtn) homeWalkthroughBtn.onclick = openWalkthroughModal;
  }

  // --- View: Gap Dashboard (Part A) ---
  function renderDashboard(container) {
    const analyzed = analyzeHealthcareGaps(state.communities, state.facilities, state.camps);
    
    // Filter by priority if set
    const filteredCommunities = state.selectedPriorityFilter === 'all'
      ? analyzed
      : analyzed.filter(a => a.priority === state.selectedPriorityFilter);

    const highPriorityList = analyzed.filter(a => a.priority === 'high');
    const medPriorityList = analyzed.filter(a => a.priority === 'medium');
    const lowPriorityList = analyzed.filter(a => a.priority === 'low');

    const totalPop = state.communities.reduce((acc, c) => acc + (c.population || 0), 0);
    const totalScreened = state.communities.reduce((acc, c) => acc + (c.people_screened || 0), 0);
    const overallCoverage = ((totalScreened / totalPop) * 100).toFixed(1);

    container.innerHTML = `
      <div class="space-y-6 py-6">
        <!-- Dashboard Header -->
        <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-white p-6 rounded-2xl border border-slate-200 shadow-xs">
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-2xl font-black text-slate-900 tracking-tight">Healthcare Gap Dashboard</h2>
              <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200">Part A</span>
            </div>
            <p class="text-xs text-slate-500 mt-1">
              Transparent, explainable gap identification across sample Maharashtra communities.
            </p>
          </div>
          <div class="flex items-center gap-2">
            <button id="dash-schedule-camp-btn" class="bg-sky-600 hover:bg-sky-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5">
              <span>✚</span> ${t('scheduleCampAction')}
            </button>
            <button id="dash-view-map-btn" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-4 py-2 rounded-xl text-xs font-semibold border border-slate-200 transition flex items-center gap-1.5">
              <span>🗺️</span> View Priority Map
            </button>
          </div>
        </div>

        <!-- Metrics Overview Cards -->
        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div class="text-xs font-bold text-slate-500 uppercase">Screened vs Population</div>
            <div class="text-2xl font-black text-slate-900 mt-2">${totalScreened.toLocaleString()} <span class="text-xs font-normal text-slate-400">/ ${totalPop.toLocaleString()}</span></div>
            <div class="text-xs text-sky-600 font-medium mt-1">${overallCoverage}% overall sample coverage</div>
          </div>

          <div class="bg-rose-50/70 p-5 rounded-2xl border border-rose-200 shadow-xs">
            <div class="text-xs font-bold text-rose-800 uppercase">Urgent Outreach Needed</div>
            <div class="text-2xl font-black text-rose-600 mt-2">${highPriorityList.length} <span class="text-xs font-normal text-rose-700">Areas</span></div>
            <div class="text-xs text-rose-700 font-medium mt-1">&lt;20% screening &amp; remote access</div>
          </div>

          <div class="bg-amber-50/70 p-5 rounded-2xl border border-amber-200 shadow-xs">
            <div class="text-xs font-bold text-amber-800 uppercase">Investigation Recommended</div>
            <div class="text-2xl font-black text-amber-600 mt-2">${medPriorityList.length} <span class="text-xs font-normal text-amber-700">Areas</span></div>
            <div class="text-xs text-amber-700 font-medium mt-1">Facility access or awareness gap</div>
          </div>

          <div class="bg-emerald-50/70 p-5 rounded-2xl border border-emerald-200 shadow-xs">
            <div class="text-xs font-bold text-emerald-800 uppercase">Baseline Outreach</div>
            <div class="text-2xl font-black text-emerald-600 mt-2">${lowPriorityList.length} <span class="text-xs font-normal text-emerald-700">Areas</span></div>
            <div class="text-xs text-emerald-700 font-medium mt-1">&gt;35% screening with local facility</div>
          </div>
        </div>

        <!-- Visual Analytics Section (Charts) -->
        <div class="grid lg:grid-cols-3 gap-6">
          <!-- Chart 1: Screening Coverage Bar Chart -->
          <div class="lg:col-span-2 bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div class="flex justify-between items-center">
              <div>
                <h3 class="font-bold text-slate-900 text-sm">Screening Coverage by Area (%)</h3>
                <p class="text-xs text-slate-500">Benchmark: Lower coverage indicates need for outreach assessment.</p>
              </div>
              <span class="text-xs font-semibold px-2 py-0.5 rounded bg-slate-100 text-slate-700 border">20% Threshold</span>
            </div>
            <div class="relative h-64 w-full">
              <canvas id="coverage-bar-chart"></canvas>
            </div>
          </div>

          <!-- Chart 2: Priority Distribution Doughnut Chart -->
          <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
            <div>
              <h3 class="font-bold text-slate-900 text-sm">Outreach Priority Breakdown</h3>
              <p class="text-xs text-slate-500">Transparent rule-based priority categorization</p>
            </div>
            <div class="relative h-64 w-full flex items-center justify-center">
              <canvas id="priority-pie-chart"></canvas>
            </div>
          </div>
        </div>

        <!-- Priority Ranking & Explainable Gap Table -->
        <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div class="p-5 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <h3 class="font-bold text-slate-900 text-base">Community Access Gap Ranking</h3>
              <p class="text-xs text-slate-500">
                Transparent multi-factor assessment: Coverage %, Facility Distance, Recent Camp Cadence.
              </p>
            </div>
            <!-- Priority Filter Tabs -->
            <div class="flex items-center gap-1 bg-slate-100 p-1 rounded-xl text-xs font-semibold">
              <button class="priority-filter-btn px-2.5 py-1 rounded-lg ${state.selectedPriorityFilter === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600'}" data-priority="all">All (${analyzed.length})</button>
              <button class="priority-filter-btn px-2.5 py-1 rounded-lg ${state.selectedPriorityFilter === 'high' ? 'bg-rose-600 text-white shadow-xs' : 'text-rose-700'}" data-priority="high">High (${highPriorityList.length})</button>
              <button class="priority-filter-btn px-2.5 py-1 rounded-lg ${state.selectedPriorityFilter === 'medium' ? 'bg-amber-600 text-white shadow-xs' : 'text-amber-700'}" data-priority="medium">Medium (${medPriorityList.length})</button>
              <button class="priority-filter-btn px-2.5 py-1 rounded-lg ${state.selectedPriorityFilter === 'low' ? 'bg-emerald-600 text-white shadow-xs' : 'text-emerald-700'}" data-priority="low">Low (${lowPriorityList.length})</button>
            </div>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
              <thead>
                <tr class="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <th class="p-3.5">Community / Area</th>
                  <th class="p-3.5">Population</th>
                  <th class="p-3.5">Screened Count</th>
                  <th class="p-3.5">Coverage Rate</th>
                  <th class="p-3.5">Nearest Facility</th>
                  <th class="p-3.5">Recent Camps</th>
                  <th class="p-3.5">Priority Flag</th>
                  <th class="p-3.5">Explainable Rationale &amp; Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                ${filteredCommunities.map(c => `
                  <tr class="hover:bg-slate-50/80 transition ${c.priority === 'high' ? 'bg-rose-50/20' : ''}">
                    <td class="p-3.5">
                      <div class="font-bold text-slate-900 text-sm">${c.area_name}</div>
                      <div class="text-slate-400 text-xs">${c.district} • PIN ${c.pincode}</div>
                    </td>
                    <td class="p-3.5 font-medium text-slate-700">${c.population.toLocaleString()}</td>
                    <td class="p-3.5 font-bold text-slate-900">${c.people_screened.toLocaleString()}</td>
                    <td class="p-3.5">
                      <div class="flex items-center gap-2">
                        <span class="font-extrabold text-sm ${c.coveragePercent < 20 ? 'text-rose-600' : c.coveragePercent < 35 ? 'text-amber-600' : 'text-emerald-600'}">
                          ${c.coveragePercent}%
                        </span>
                      </div>
                      <div class="w-20 bg-slate-200 h-1.5 rounded-full mt-1 overflow-hidden">
                        <div class="h-full ${c.coveragePercent < 20 ? 'bg-rose-500' : c.coveragePercent < 35 ? 'bg-amber-500' : 'bg-emerald-500'}" style="width: ${Math.min(100, c.coveragePercent)}%"></div>
                      </div>
                    </td>
                    <td class="p-3.5">
                      <div class="font-medium text-slate-800">${c.nearest_facility_km} km</div>
                      <div class="text-slate-500 text-[11px] truncate max-w-[140px]" title="${c.nearestFacility ? c.nearestFacility.name : 'Public Facility'}">
                        ${c.nearestFacility ? c.nearestFacility.name : 'Public Facility'}
                      </div>
                    </td>
                    <td class="p-3.5">
                      <span class="px-2 py-0.5 rounded-full font-semibold ${c.recent_camps_count === 0 ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'}">
                        ${c.recent_camps_count} camps
                      </span>
                    </td>
                    <td class="p-3.5">
                      <span class="px-2.5 py-1 rounded-full text-xs font-bold border ${c.badgeClass}">
                        ${c.priority === 'high' ? 'High Priority' : c.priority === 'medium' ? 'Medium' : 'Baseline'}
                      </span>
                    </td>
                    <td class="p-3.5">
                      <div class="space-y-1 max-w-sm">
                        <div class="text-slate-700 font-medium">
                          ${c.reasons.join(' • ')}
                        </div>
                        <div class="text-slate-500 text-[11px] italic">
                          💡 ${c.recommendation}
                        </div>
                        <div class="pt-1 flex gap-2">
                          <button class="table-schedule-camp-btn text-xs font-bold text-sky-600 hover:text-sky-800 underline" data-area-id="${c.area_id}">
                            + Schedule Camp Here
                          </button>
                        </div>
                      </div>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    // Priority filter handlers
    document.querySelectorAll('.priority-filter-btn').forEach(btn => {
      btn.onclick = () => {
        state.selectedPriorityFilter = btn.dataset.priority;
        renderDashboard(container);
      };
    });

    // Schedule Camp Buttons in table
    document.querySelectorAll('.table-schedule-camp-btn').forEach(btn => {
      btn.onclick = () => {
        openScheduleCampModal({ prefillAreaId: btn.dataset.areaId });
      };
    });

    const dashScheduleBtn = document.getElementById('dash-schedule-camp-btn');
    if (dashScheduleBtn) dashScheduleBtn.onclick = () => openScheduleCampModal();

    const dashMapBtn = document.getElementById('dash-view-map-btn');
    if (dashMapBtn) dashMapBtn.onclick = () => navigateTo('map');

    // Initialize Chart.js Graphs
    initDashboardCharts(analyzed, highPriorityList.length, medPriorityList.length, lowPriorityList.length);
  }

  function initDashboardCharts(analyzed, highCount, medCount, lowCount) {
    if (!window.Chart) return;

    if (state.charts.coverage) state.charts.coverage.destroy();
    if (state.charts.priority) state.charts.priority.destroy();

    const ctxBar = document.getElementById('coverage-bar-chart');
    if (ctxBar) {
      const labels = analyzed.map(c => c.area_name.split(' (')[0]);
      const data = analyzed.map(c => c.coveragePercent);
      const bgColors = analyzed.map(c => 
        c.coveragePercent < 20 ? 'rgba(239, 68, 68, 0.85)' : 
        c.coveragePercent < 35 ? 'rgba(245, 158, 11, 0.85)' : 
        'rgba(16, 185, 129, 0.85)'
      );

      state.charts.coverage = new window.Chart(ctxBar, {
        type: 'bar',
        data: {
          labels,
          datasets: [{
            label: 'Screening Coverage (%)',
            data,
            backgroundColor: bgColors,
            borderRadius: 6
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: { display: false },
            tooltip: {
              callbacks: {
                label: (ctx) => `Coverage: ${ctx.raw}% (${analyzed[ctx.dataIndex].priorityLabel})`
              }
            }
          },
          scales: {
            y: {
              beginAtZero: true,
              max: 65,
              ticks: { callback: v => `${v}%` },
              grid: { color: '#f1f5f9' }
            },
            x: {
              grid: { display: false }
            }
          }
        }
      });
    }

    const ctxPie = document.getElementById('priority-pie-chart');
    if (ctxPie) {
      state.charts.priority = new window.Chart(ctxPie, {
        type: 'doughnut',
        data: {
          labels: ['High Priority (Urgent)', 'Medium Priority (Assess)', 'Lower Priority (Baseline)'],
          datasets: [{
            data: [highCount, medCount, lowCount],
            backgroundColor: [
              'rgba(239, 68, 68, 0.9)',
              'rgba(245, 158, 11, 0.9)',
              'rgba(16, 185, 129, 0.9)'
            ],
            borderWidth: 2,
            borderColor: '#ffffff'
          }]
        },
        options: {
          responsive: true,
          maintainAspectRatio: false,
          plugins: {
            legend: {
              position: 'bottom',
              labels: { boxWidth: 12, font: { size: 11 } }
            }
          },
          cutout: '68%'
        }
      });
    }
  }

  // --- View: Find Health Camps (Part B) ---
  function renderCamps(container) {
    const q = (state.searchQuery || '').toLowerCase();
    const pinInfo = state.pincodeInfo;
    const isResolving = pinInfo && pinInfo.isResolving;

    // Filter camps
    const filteredCamps = state.camps.filter(camp => {
      // 1. Text Search matching
      let matchesSearch = !q ||
        camp.name.toLowerCase().includes(q) ||
        camp.area_name.toLowerCase().includes(q) ||
        (camp.directions && camp.directions.toLowerCase().includes(q)) ||
        (camp.pincode && camp.pincode.includes(q)) ||
        (camp.district && camp.district.toLowerCase().includes(q)) ||
        (camp.taluka && camp.taluka.toLowerCase().includes(q)) ||
        camp.services.some(s => s.toLowerCase().includes(q));

      // 2. If a PIN code was resolved via API: match PIN, district, or block
      if (pinInfo && pinInfo.pincode) {
        const pin = pinInfo.pincode;
        const matchesExactPin = (camp.pincode && camp.pincode === pin);
        const matchesDistrict = (pinInfo.district && camp.district && camp.district.toLowerCase() === pinInfo.district.toLowerCase());
        const matchesTaluka = (pinInfo.block && camp.taluka && camp.taluka.toLowerCase().includes(pinInfo.block.toLowerCase()));
        const matchesPO = pinInfo.postOffices && pinInfo.postOffices.some(po => camp.area_name.toLowerCase().includes(po.toLowerCase()));
        
        // Include if matches exact PIN or district/taluka
        matchesSearch = matchesExactPin || matchesTaluka || matchesDistrict || matchesPO || matchesSearch;
      }

      // 3. Date / status filter
      let matchesDate = true;
      if (state.selectedCampFilter === 'upcoming') {
        matchesDate = camp.status === 'upcoming';
      } else if (state.selectedCampFilter === 'completed') {
        matchesDate = camp.status === 'completed';
      } else if (state.selectedCampFilter === 'today') {
        matchesDate = camp.status === 'upcoming';
      }

      // 4. Service type filter
      let matchesService = true;
      if (state.selectedServiceFilter !== 'all') {
        matchesService = (camp.service_types && camp.service_types.includes(state.selectedServiceFilter)) ||
          camp.services.some(s => s.toLowerCase().includes(state.selectedServiceFilter.toLowerCase()));
      }

      return matchesSearch && matchesDate && matchesService;
    });

    // Check if the resolved PIN belongs to a known gap community
    let pinGapCommunity = null;
    if (pinInfo && pinInfo.pincode) {
      const analyzed = analyzeHealthcareGaps(state.communities, state.facilities, state.camps);
      pinGapCommunity = analyzed.find(c => c.pincode === pinInfo.pincode || (c.district.toLowerCase() === pinInfo.district.toLowerCase() && c.priority === 'high'));
    }

    container.innerHTML = `
      <div class="space-y-6 py-6">
        <!-- Page Header & Search Bar -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <div class="flex items-center gap-2">
                <h2 class="text-2xl font-black text-slate-900 tracking-tight">Community Health Camps</h2>
                <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">Part B</span>
              </div>
              <p class="text-xs text-slate-500 mt-1">
                Enter your village, city, or 6-digit postal PIN code to discover free camps and checkups.
              </p>
            </div>
            <button id="btn-add-camp-header" class="bg-sky-600 hover:bg-sky-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5">
              <span>✚</span> Register New Camp
            </button>
          </div>

          <!-- Postal PIN Code / Locality Search Input -->
          <div class="flex flex-col sm:flex-row gap-2">
            <div class="flex-1 flex items-center px-3.5 py-2 rounded-xl border border-slate-300 bg-slate-50 focus-within:bg-white focus-within:border-sky-500 gap-2">
              <span class="text-sky-600">📮</span>
              <input type="text" id="camps-search-input" value="${state.searchQuery}" placeholder="${t('quickSearchPlaceholder')}" class="w-full text-sm bg-transparent focus:outline-none" />
              ${state.searchQuery ? `<button id="camps-clear-search" class="text-xs text-slate-400 hover:text-slate-700">✕ Clear</button>` : ''}
            </div>
            <button id="camps-search-btn" class="bg-sky-600 hover:bg-sky-700 text-white px-6 py-2 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5">
              <span>🔍</span> Filter / Resolve PIN
            </button>
          </div>

          <!-- Quick PIN Suggestions -->
          <div class="flex flex-wrap items-center gap-2 text-xs text-slate-500 pt-1">
            <span class="font-bold text-slate-600">Quick PINs:</span>
            <button class="camps-quick-pin px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border font-mono" data-pin="413120">413120 (Indapur)</button>
            <button class="camps-quick-pin px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border font-mono" data-pin="412207">412207 (Koregaon)</button>
            <button class="camps-quick-pin px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border font-mono" data-pin="412802">412802 (Ambegaon/Satara)</button>
            <button class="camps-quick-pin px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border font-mono" data-pin="411015">411015 (Dhanori)</button>
            <button class="camps-quick-pin px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border font-mono" data-pin="411001">411001 (Pune GPO)</button>
            <button class="camps-quick-pin px-2.5 py-1 rounded bg-slate-100 hover:bg-slate-200 text-slate-700 border font-mono" data-pin="400001">400001 (Mumbai)</button>
          </div>

          <!-- Filter Pills -->
          <div class="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
            <div class="flex flex-wrap items-center gap-1.5">
              <span class="font-bold text-slate-500 mr-1">Status:</span>
              <button class="camp-status-filter px-3 py-1 rounded-lg ${state.selectedCampFilter === 'all' ? 'bg-slate-900 text-white font-semibold' : 'bg-slate-100 text-slate-600'}" data-filter="all">All (${state.camps.length})</button>
              <button class="camp-status-filter px-3 py-1 rounded-lg ${state.selectedCampFilter === 'upcoming' ? 'bg-sky-600 text-white font-semibold' : 'bg-slate-100 text-slate-600'}" data-filter="upcoming">Upcoming</button>
              <button class="camp-status-filter px-3 py-1 rounded-lg ${state.selectedCampFilter === 'completed' ? 'bg-emerald-600 text-white font-semibold' : 'bg-slate-100 text-slate-600'}" data-filter="completed">Past / Completed</button>
            </div>

            <div class="flex items-center gap-1.5">
              <span class="font-bold text-slate-500">Service:</span>
              <select id="camp-service-select" class="text-xs font-medium border border-slate-300 rounded-lg px-2.5 py-1 bg-white focus:outline-none">
                <option value="all" ${state.selectedServiceFilter === 'all' ? 'selected' : ''}>All Services</option>
                <option value="Screening" ${state.selectedServiceFilter === 'Screening' ? 'selected' : ''}>Blood Pressure / Diabetes</option>
                <option value="Maternal Care" ${state.selectedServiceFilter === 'Maternal Care' ? 'selected' : ''}>Maternal &amp; Child</option>
                <option value="Eye Screening" ${state.selectedServiceFilter === 'Eye Screening' ? 'selected' : ''}>Eye Screening / Cataract</option>
                <option value="Vaccination" ${state.selectedServiceFilter === 'Vaccination' ? 'selected' : ''}>Vaccination / Immunization</option>
                <option value="General OPD" ${state.selectedServiceFilter === 'General OPD' ? 'selected' : ''}>General OPD &amp; Medicine</option>
              </select>
            </div>
          </div>
        </div>

        <!-- 📮 Postal PIN Code API Resolution Live Banner -->
        ${isResolving ? `
          <div class="bg-sky-50 border border-sky-300 rounded-2xl p-4 flex items-center gap-3 text-sky-800 text-xs animate-pulse">
            <span class="text-2xl">⏳</span>
            <div>
              <div class="font-extrabold text-sm">${t('pinResolving')}</div>
              <div class="text-sky-600 mt-0.5">Fetching verified postal office details, district, and healthcare services for PIN <strong>${pinInfo.pincode}</strong>...</div>
            </div>
          </div>
        ` : pinInfo ? `
          <div class="bg-gradient-to-r from-sky-50 via-teal-50 to-emerald-50 border border-sky-200 rounded-2xl p-5 shadow-xs space-y-3">
            <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
              <div class="flex items-center gap-3">
                <div class="w-10 h-10 rounded-xl bg-sky-600 text-white flex items-center justify-center font-bold text-lg shadow-sm">
                  📮
                </div>
                <div>
                  <div class="flex items-center gap-2">
                    <span class="font-extrabold text-slate-900 text-base">Postal Area: PIN ${pinInfo.pincode}</span>
                    <span class="px-2 py-0.5 rounded-full text-[11px] font-bold bg-sky-100 text-sky-800 border border-sky-200">
                      ✓ ${pinInfo.source || t('postalApiTag')}
                    </span>
                  </div>
                  <div class="text-xs text-slate-600 mt-0.5 font-medium">
                    📍 <strong>${pinInfo.postOffices ? pinInfo.postOffices.slice(0, 3).join(', ') : 'Locality'}</strong>
                    • Taluka/Block: <strong>${pinInfo.block || 'Taluka'}</strong> • District: <strong>${pinInfo.district}</strong>, ${pinInfo.state}
                  </div>
                </div>
              </div>
              <button id="btn-request-camp-pin" class="bg-sky-600 hover:bg-sky-700 text-white px-3.5 py-1.5 rounded-xl text-xs font-bold shadow-xs transition flex items-center gap-1" data-pin="${pinInfo.pincode}" data-district="${pinInfo.district}">
                <span>✚</span> Request Camp in PIN ${pinInfo.pincode}
              </button>
            </div>

            <!-- Healthcare Gap Flag for this postal area -->
            ${pinGapCommunity ? `
              <div class="p-3 bg-rose-50 border border-rose-200 rounded-xl text-xs text-rose-900 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2">
                <div class="flex items-center gap-2">
                  <span class="text-rose-600 font-bold text-base">⚠️</span>
                  <span>
                    <strong>Healthcare Access Gap Detected in this Postal Zone:</strong> ${pinGapCommunity.area_name} has only <strong>${pinGapCommunity.coveragePercent}% screening coverage</strong> and the nearest hospital is <strong>${pinGapCommunity.nearest_facility_km} km away</strong>.
                  </span>
                </div>
                <button class="text-xs font-bold text-rose-700 hover:underline shrink-0 table-schedule-camp-btn" data-area-id="${pinGapCommunity.area_id}">
                  Schedule Camp Here →
                </button>
              </div>
            ` : `
              <div class="p-2.5 bg-white/70 border border-slate-200 rounded-xl text-xs text-slate-600 flex items-center justify-between">
                <span>Showing outreach camps &amp; public health centers for <strong>${pinInfo.district}</strong> district.</span>
                <span class="font-bold text-slate-800">${filteredCamps.length} camp(s) found</span>
              </div>
            `}
          </div>
        ` : ''}

        <!-- Camp Listings Grid -->
        ${filteredCamps.length === 0 ? `
          <div class="bg-white rounded-2xl p-10 text-center border border-slate-200 space-y-3">
            <div class="text-4xl">🏕️</div>
            <div class="font-bold text-slate-900 text-lg">No health camps scheduled in this specific area</div>
            <div class="text-xs text-slate-500 max-w-md mx-auto">
              ${pinInfo ? `
                No active outreach camps are currently listed for PIN <strong>${pinInfo.pincode}</strong> (${pinInfo.district}).
                You can explore nearby hospitals in the Directory, or request an outreach camp for this locality!
              ` : `
                No sample camps matched "${state.searchQuery}". Try searching for PIN "413120", "412207", "412802", or "Indapur".
              `}
            </div>
            <div class="flex justify-center gap-3 pt-2">
              <button id="reset-camp-filters" class="text-xs font-bold text-sky-600 hover:underline">
                Clear All Filters
              </button>
              ${pinInfo ? `
                <button id="btn-request-camp-empty" class="bg-sky-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold">
                  + Request Camp for PIN ${pinInfo.pincode}
                </button>
              ` : ''}
            </div>
          </div>
        ` : `
          <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-5">
            ${filteredCamps.map(camp => `
              <div class="bg-white rounded-2xl border border-slate-200 shadow-xs hover:shadow-md transition flex flex-col justify-between overflow-hidden">
                <div>
                  <!-- Top Status Bar -->
                  <div class="px-5 py-3 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
                    <span class="px-2.5 py-0.5 rounded-full text-[11px] font-bold ${
                      camp.status === 'upcoming' ? 'bg-sky-100 text-sky-800 border border-sky-200' : 'bg-slate-200 text-slate-700'
                    }">
                      ${camp.status === 'upcoming' ? '● Upcoming Camp' : '✓ Completed Event'}
                    </span>
                    <span class="text-[11px] font-medium text-slate-500">
                      📅 ${camp.date}
                    </span>
                  </div>

                  <!-- Camp Content -->
                  <div class="p-5 space-y-3">
                    <div>
                      <div class="text-xs font-bold text-sky-700 flex items-center gap-1">
                        <span>📍</span> ${camp.area_name}
                        ${camp.pincode ? `<span class="font-mono text-slate-400 font-normal">(${camp.pincode})</span>` : ''}
                      </div>
                      <h3 class="font-extrabold text-slate-900 text-base leading-snug mt-1">
                        ${camp.name}
                      </h3>
                    </div>

                    <!-- Services Badges -->
                    <div class="flex flex-wrap gap-1.5">
                      ${camp.services.map(s => `
                        <span class="px-2 py-0.5 rounded-md text-[11px] font-medium bg-slate-100 text-slate-700 border border-slate-200">
                          ${s}
                        </span>
                      `).join('')}
                    </div>

                    <!-- Details Snippet -->
                    <div class="space-y-1.5 text-xs text-slate-600 pt-1">
                      <div class="flex items-start gap-2">
                        <span class="text-slate-400 font-bold">⏰</span>
                        <span>${camp.time}</span>
                      </div>
                      <div class="flex items-start gap-2">
                        <span class="text-slate-400 font-bold">🏛️</span>
                        <span>${camp.venue}</span>
                      </div>
                      <div class="flex items-start gap-2">
                        <span class="text-slate-400 font-bold">👥</span>
                        <span>${camp.eligibility}</span>
                      </div>
                    </div>

                    ${camp.status === 'completed' && camp.attendance_recorded ? `
                      <div class="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs text-emerald-800 flex items-center justify-between">
                        <span class="font-semibold">Recorded Attendance:</span>
                        <span class="font-black text-sm">${camp.attendance_recorded} screened</span>
                      </div>
                    ` : ''}
                  </div>
                </div>

                <!-- Footer Action Buttons -->
                <div class="p-4 bg-slate-50/80 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
                  <button class="camp-details-btn text-xs font-bold text-sky-700 hover:text-sky-900 py-1.5 px-2.5 rounded-lg hover:bg-sky-100 transition" data-camp-id="${camp.camp_id}">
                    Details →
                  </button>
                  <div class="flex items-center gap-1.5">
                    ${camp.status === 'upcoming' ? `
                      <button class="camp-pre-reg-btn bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold py-1.5 px-2.5 rounded-lg shadow-xs transition flex items-center gap-1" data-camp-id="${camp.camp_id}">
                        <span>🎫</span> Register Visit
                      </button>
                      <button class="camp-reminder-btn bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold py-1.5 px-2 rounded-lg border transition" data-camp-id="${camp.camp_id}" title="Set Reminder">
                        🔔
                      </button>
                    ` : `
                      <button class="camp-record-btn text-xs font-semibold text-slate-600 hover:text-slate-900 py-1.5 px-3 rounded-lg border border-slate-200" data-camp-id="${camp.camp_id}">
                        Log Attendance
                      </button>
                    `}
                  </div>
                </div>
              </div>
            `).join('')}
          </div>
        `}
      </div>
    `;

    // Search and filter event handlers
    const campsSearchInput = document.getElementById('camps-search-input');
    const campsSearchBtn = document.getElementById('camps-search-btn');
    const clearBtn = document.getElementById('camps-clear-search');
    const resetBtn = document.getElementById('reset-camp-filters');

    if (campsSearchBtn && campsSearchInput) {
      campsSearchBtn.onclick = () => executeSearch(campsSearchInput.value, 'camps');
      campsSearchInput.onkeydown = (e) => {
        if (e.key === 'Enter') executeSearch(campsSearchInput.value, 'camps');
      };
    }

    if (clearBtn) {
      clearBtn.onclick = () => {
        state.searchQuery = '';
        state.pincodeInfo = null;
        renderCamps(container);
      };
    }

    if (resetBtn) {
      resetBtn.onclick = () => {
        state.searchQuery = '';
        state.pincodeInfo = null;
        state.selectedCampFilter = 'all';
        state.selectedServiceFilter = 'all';
        renderCamps(container);
      };
    }

    document.querySelectorAll('.camps-quick-pin').forEach(btn => {
      btn.onclick = () => {
        executeSearch(btn.dataset.pin, 'camps');
      };
    });

    document.querySelectorAll('.camp-status-filter').forEach(btn => {
      btn.onclick = () => {
        state.selectedCampFilter = btn.dataset.filter;
        renderCamps(container);
      };
    });

    const serviceSelect = document.getElementById('camp-service-select');
    if (serviceSelect) {
      serviceSelect.onchange = () => {
        state.selectedServiceFilter = serviceSelect.value;
        renderCamps(container);
      };
    }

    // Modal Triggers
    document.querySelectorAll('.camp-details-btn').forEach(btn => {
      btn.onclick = () => openCampDetailsModal(btn.dataset.campId);
    });

    document.querySelectorAll('.camp-pre-reg-btn').forEach(btn => {
      btn.onclick = () => openRegisterWithCenter(btn.dataset.campId, 'camp');
    });

    document.querySelectorAll('.camp-reminder-btn').forEach(btn => {
      btn.onclick = () => openReminderModal(btn.dataset.campId);
    });

    document.querySelectorAll('.camp-record-btn').forEach(btn => {
      btn.onclick = () => openRecordAttendanceModal(btn.dataset.campId);
    });

    const addCampHeaderBtn = document.getElementById('btn-add-camp-header');
    if (addCampHeaderBtn) addCampHeaderBtn.onclick = () => openScheduleCampModal();

    const requestPinBtn = document.getElementById('btn-request-camp-pin');
    if (requestPinBtn) {
      requestPinBtn.onclick = () => {
        openScheduleCampModal({
          prefillPincode: requestPinBtn.dataset.pin,
          prefillDistrict: requestPinBtn.dataset.district
        });
      };
    }

    const requestPinEmptyBtn = document.getElementById('btn-request-camp-empty');
    if (requestPinEmptyBtn && state.pincodeInfo) {
      requestPinEmptyBtn.onclick = () => {
        openScheduleCampModal({
          prefillPincode: state.pincodeInfo.pincode,
          prefillDistrict: state.pincodeInfo.district
        });
      };
    }
  }

  // --- View: Public Healthcare Directory (Part B) ---
  function renderFacilities(container) {
    const q = (state.searchQuery || '').toLowerCase();
    const pinInfo = state.pincodeInfo;

    const filteredFacilities = state.facilities.filter(fac => {
      let matchesSearch = !q ||
        fac.name.toLowerCase().includes(q) ||
        fac.district.toLowerCase().includes(q) ||
        fac.address.toLowerCase().includes(q) ||
        (fac.pincode && fac.pincode.includes(q)) ||
        fac.services.some(s => s.toLowerCase().includes(q));

      // Match resolved PIN or district
      if (pinInfo && pinInfo.pincode) {
        const matchesExactPin = (fac.pincode && fac.pincode === pinInfo.pincode);
        const matchesDistrict = (pinInfo.district && fac.district && fac.district.toLowerCase() === pinInfo.district.toLowerCase());
        matchesSearch = matchesExactPin || matchesDistrict || matchesSearch;
      }

      const matchesType = state.selectedFacilityTypeFilter === 'all' ||
        fac.type === state.selectedFacilityTypeFilter;

      return matchesSearch && matchesType;
    });

    container.innerHTML = `
      <div class="space-y-6 py-6">
        <!-- Directory Header -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2">
            <div>
              <div class="flex items-center gap-2">
                <h2 class="text-2xl font-black text-slate-900 tracking-tight">Public Healthcare Directory</h2>
                <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-sky-100 text-sky-800 border border-sky-200">Government Facilities</span>
              </div>
              <p class="text-xs text-slate-500 mt-1">
                Verified directory of Primary Health Centres (PHC), Community Health Centres (CHC), and District Hospitals.
              </p>
            </div>
          </div>

          <!-- Facility Search Input -->
          <div class="flex flex-col sm:flex-row gap-2 pt-1">
            <div class="flex-1 flex items-center px-3.5 py-2 rounded-xl border border-slate-300 bg-slate-50 focus-within:bg-white focus-within:border-sky-500 gap-2">
              <span class="text-sky-600">📮</span>
              <input type="text" id="fac-search-input" value="${state.searchQuery}" placeholder="Search facilities by PIN code, district, or hospital name..." class="w-full text-sm bg-transparent focus:outline-none" />
              ${state.searchQuery ? `<button id="fac-clear-search" class="text-xs text-slate-400 hover:text-slate-700">✕ Clear</button>` : ''}
            </div>
            <button id="fac-search-btn" class="bg-sky-600 hover:bg-sky-700 text-white px-5 py-2 rounded-xl text-xs font-bold transition">
              Find Facilities
            </button>
          </div>

          <!-- Facility Type Filters -->
          <div class="flex flex-wrap gap-2 text-xs font-semibold pt-2 border-t border-slate-100">
            <button class="fac-type-filter px-3 py-1.5 rounded-lg ${state.selectedFacilityTypeFilter === 'all' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}" data-type="all">All Types (${state.facilities.length})</button>
            <button class="fac-type-filter px-3 py-1.5 rounded-lg ${state.selectedFacilityTypeFilter === 'Primary Health Centre' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}" data-type="Primary Health Centre">Primary Health Centres (PHC)</button>
            <button class="fac-type-filter px-3 py-1.5 rounded-lg ${state.selectedFacilityTypeFilter === 'Community Health Centre' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}" data-type="Community Health Centre">Community Health Centres (CHC)</button>
            <button class="fac-type-filter px-3 py-1.5 rounded-lg ${state.selectedFacilityTypeFilter === 'Sub-District Hospital' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}" data-type="Sub-District Hospital">Sub-District Hospitals</button>
            <button class="fac-type-filter px-3 py-1.5 rounded-lg ${state.selectedFacilityTypeFilter === 'Health & Wellness Sub-Centre' ? 'bg-sky-600 text-white' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}" data-type="Health & Wellness Sub-Centre">Sub-Centres &amp; Wellness</button>
          </div>
        </div>

        <!-- Facilities Cards -->
        <div class="grid md:grid-cols-2 gap-5">
          ${filteredFacilities.map(fac => `
            <div class="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 flex flex-col justify-between hover:shadow-md transition">
              <div class="space-y-3">
                <div class="flex items-start justify-between gap-3">
                  <div>
                    <div class="flex items-center gap-1.5">
                      <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-sky-50 text-sky-800 border border-sky-200">
                        ${fac.type}
                      </span>
                      ${fac.pincode ? `<span class="text-[11px] font-mono text-slate-500 font-semibold">PIN ${fac.pincode}</span>` : ''}
                    </div>
                    <h3 class="font-black text-slate-900 text-lg leading-tight mt-1.5">
                      ${fac.name}
                    </h3>
                  </div>
                  <div class="w-8 h-8 rounded-lg bg-sky-100 text-sky-700 flex items-center justify-center font-bold text-sm shrink-0">
                    🏥
                  </div>
                </div>

                <div class="text-xs text-slate-600 flex items-start gap-1.5">
                  <span class="text-slate-400">📍</span>
                  <span>${fac.address}</span>
                </div>

                <!-- Verified Key Badges -->
                <div class="flex flex-wrap gap-2 text-[11px]">
                  ${fac.emergency_24x7 ? `<span class="px-2 py-0.5 rounded-full font-bold bg-rose-100 text-rose-800 border border-rose-200">24/7 Emergency</span>` : ''}
                  ${fac.maternity_delivery ? `<span class="px-2 py-0.5 rounded-full font-bold bg-pink-100 text-pink-800 border border-pink-200">Maternity Delivery</span>` : ''}
                  ${fac.free_drugs ? `<span class="px-2 py-0.5 rounded-full font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">Free Essential Medicines</span>` : ''}
                  ${fac.ambulance_available ? `<span class="px-2 py-0.5 rounded-full font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">Ambulance On-Site</span>` : ''}
                </div>

                <!-- Operating Hours & Contact -->
                <div class="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs space-y-1.5">
                  <div class="flex items-center justify-between">
                    <span class="text-slate-500 font-medium">Verified Hours:</span>
                    <span class="font-semibold text-slate-800">${fac.operating_hours}</span>
                  </div>
                  <div class="flex items-center justify-between">
                    <span class="text-slate-500 font-medium">Helpline / Contact:</span>
                    <a href="tel:${fac.contact_phone}" class="font-bold text-sky-700 hover:underline">${fac.contact_phone}</a>
                  </div>
                </div>

                <!-- Services List -->
                <div>
                  <div class="text-[11px] font-bold text-slate-500 uppercase tracking-wider mb-1.5">Services Provided:</div>
                  <div class="flex flex-wrap gap-1.5">
                    ${fac.services.map(s => `
                      <span class="px-2 py-0.5 rounded text-[11px] bg-slate-100 text-slate-700 border border-slate-200">
                        ${s}
                      </span>
                    `).join('')}
                  </div>
                </div>
              </div>

              <!-- Actions: Directions & Register for Visit -->
              <div class="pt-4 mt-4 border-t border-slate-100 flex flex-wrap items-center justify-between text-xs gap-2">
                <span class="text-slate-400 italic font-mono text-[11px]">${fac.verification_status}</span>
                <div class="flex items-center gap-2">
                  <a href="https://www.google.com/maps/search/?api=1&query=${fac.latitude},${fac.longitude}" target="_blank" rel="noopener noreferrer" class="font-semibold text-slate-500 hover:text-slate-800 flex items-center gap-1">
                    <span>🗺️</span> Directions
                  </a>
                  <button class="fac-register-btn bg-sky-600 hover:bg-sky-700 text-white px-3 py-1.5 rounded-xl font-bold transition flex items-center gap-1 shadow-xs" data-fac-id="${fac.facility_id}">
                    <span>✚</span> Register for Visit
                  </button>
                </div>
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;

    document.querySelectorAll('.fac-type-filter').forEach(btn => {
      btn.onclick = () => {
        state.selectedFacilityTypeFilter = btn.dataset.type;
        renderFacilities(container);
      };
    });

    document.querySelectorAll('.fac-register-btn').forEach(btn => {
      btn.onclick = () => openRegisterWithCenter(btn.dataset.facId, 'facility');
    });

    const facSearchInput = document.getElementById('fac-search-input');
    const facSearchBtn = document.getElementById('fac-search-btn');
    const facClearBtn = document.getElementById('fac-clear-search');

    if (facSearchBtn && facSearchInput) {
      facSearchBtn.onclick = () => executeSearch(facSearchInput.value, 'facilities');
      facSearchInput.onkeydown = (e) => {
        if (e.key === 'Enter') executeSearch(facSearchInput.value, 'facilities');
      };
    }
    if (facClearBtn) {
      facClearBtn.onclick = () => {
        state.searchQuery = '';
        state.pincodeInfo = null;
        renderFacilities(container);
      };
    }
  }

  // --- View: Citizen Healthcare Registration & Centre Visit Booking (Part C) ---
  function renderRegister(container) {
    const isBookTab = state.selectedRegisterTab === 'book';
    const activePasses = state.registrations.filter(r => r.status !== 'cancelled');
    const q = (state.searchQuery || '').toLowerCase();
    const pinInfo = state.pincodeInfo;

    // Determine pre-selected center if any
    let preselectedCenter = null;
    if (state.preselectedCenterId) {
      if (state.preselectedCenterType === 'camp') {
        preselectedCenter = state.camps.find(c => c.camp_id === state.preselectedCenterId);
      } else {
        preselectedCenter = state.facilities.find(f => f.facility_id === state.preselectedCenterId);
      }
    }

    // Auto-compute nearest facility if resident has a PIN or locality
    let nearestRecommendation = null;
    if (pinInfo && pinInfo.pincode) {
      nearestRecommendation = state.facilities.find(f => f.pincode === pinInfo.pincode) ||
                              state.facilities.find(f => f.district.toLowerCase() === pinInfo.district.toLowerCase()) ||
                              state.facilities[0];
    } else if (state.searchQuery) {
      nearestRecommendation = state.facilities.find(f => 
        f.address.toLowerCase().includes(q) || 
        f.district.toLowerCase().includes(q) ||
        (f.pincode && f.pincode.includes(q))
      ) || state.facilities[0];
    } else {
      nearestRecommendation = state.facilities[0];
    }

    container.innerHTML = `
      <div class="space-y-6 py-6">
        <!-- Page Header & Tab Navigation -->
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-4">
          <div class="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <div class="flex items-center gap-2">
                <h2 class="text-2xl font-black text-slate-900 tracking-tight">${t('registerTitle')}</h2>
                <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">Part C</span>
              </div>
              <p class="text-xs text-slate-500 mt-1 max-w-2xl leading-relaxed">
                ${t('registerDesc')}
              </p>
            </div>
            <div class="flex items-center gap-2 bg-slate-100 p-1 rounded-xl text-xs font-bold">
              <button id="tab-btn-book" class="px-4 py-2 rounded-lg transition ${isBookTab ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'}">
                ✚ ${t('registerTabNew')}
              </button>
              <button id="tab-btn-passes" class="px-4 py-2 rounded-lg transition ${!isBookTab ? 'bg-white text-emerald-800 shadow-xs' : 'text-slate-600 hover:text-slate-900'}">
                🎫 ${t('registerTabPasses')} (${activePasses.length})
              </button>
            </div>
          </div>
        </div>

        ${isBookTab ? `
          <!-- VIEW 1: BOOKING & REGISTRATION FORM -->
          <div class="grid lg:grid-cols-3 gap-6">
            <!-- Left 2 Cols: The Registration Form -->
            <div class="lg:col-span-2 bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-6">
              <!-- Smart Nearest Centre Recommendation Card -->
              <div class="bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 p-4 rounded-xl border border-emerald-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 text-xs">
                <div class="flex items-center gap-3">
                  <div class="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-bold text-base shadow-xs shrink-0">
                    🏥
                  </div>
                  <div>
                    <div class="font-extrabold text-emerald-950 text-sm flex items-center gap-1.5">
                      <span>${t('nearestCenterRec')}:</span>
                      <span class="px-2 py-0.5 rounded-full text-[10px] bg-emerald-200/60 text-emerald-900 font-bold">Auto-Detected</span>
                    </div>
                    <div class="text-emerald-800 mt-0.5 font-medium">
                      <strong>${preselectedCenter ? preselectedCenter.name : nearestRecommendation.name}</strong> • 
                      ${preselectedCenter ? (preselectedCenter.venue || preselectedCenter.address) : nearestRecommendation.address}
                      ${nearestRecommendation.operating_hours ? `(${nearestRecommendation.operating_hours})` : ''}
                    </div>
                  </div>
                </div>
                <button id="btn-use-recommended" class="bg-emerald-700 hover:bg-emerald-800 text-white px-3 py-1.5 rounded-lg font-bold shrink-0 shadow-xs transition">
                  ✓ Select This Centre
                </button>
              </div>

              <form id="user-registration-form" class="space-y-6 text-xs">
                <!-- Step 1: Citizen Demographics -->
                <div class="space-y-3">
                  <div class="flex items-center gap-2 border-b border-slate-100 pb-2">
                    <span class="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[11px]">1</span>
                    <h3 class="font-extrabold text-slate-900 text-sm">Citizen &amp; Contact Details</h3>
                  </div>

                  <div class="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label class="block font-bold text-slate-700 mb-1">Full Name *</label>
                      <input type="text" id="reg-name" required placeholder="e.g. Ramesh Pawar or Sunita Shinde" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-slate-50 focus:bg-white" />
                    </div>

                    <div class="grid grid-cols-2 gap-2">
                      <div>
                        <label class="block font-bold text-slate-700 mb-1">Age *</label>
                        <input type="number" id="reg-age" required min="1" max="115" placeholder="e.g. 42" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-slate-50 focus:bg-white" />
                      </div>
                      <div>
                        <label class="block font-bold text-slate-700 mb-1">Gender *</label>
                        <select id="reg-gender" required class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-slate-50 focus:bg-white">
                          <option value="Male">Male (पुरुष)</option>
                          <option value="Female">Female (स्त्री)</option>
                          <option value="Other">Other (इतर)</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label class="block font-bold text-slate-700 mb-1">Mobile Contact (for SMS Token) *</label>
                      <input type="tel" id="reg-phone" required pattern="[0-9+ -]{10,14}" placeholder="+91 98XXX XXXXX" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-slate-50 focus:bg-white" />
                      <span class="text-[10px] text-slate-400 mt-0.5 block">Token number will be dispatched to this phone.</span>
                    </div>

                    <div>
                      <label class="block font-bold text-slate-700 mb-1">Village / Locality / PIN Code *</label>
                      <div class="flex gap-1.5">
                        <input type="text" id="reg-pincode" required value="${pinInfo ? pinInfo.pincode : (state.searchQuery || '413120')}" placeholder="e.g. 413120 or Nimgaon" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-slate-50 focus:bg-white font-mono" />
                        <button type="button" id="btn-detect-loc" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-3 py-1 rounded-xl font-bold border transition text-[11px] whitespace-nowrap">
                          🔍 Find Centre
                        </button>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- Step 2: Choose Centre -->
                <div class="space-y-3">
                  <div class="flex items-center justify-between border-b border-slate-100 pb-2">
                    <div class="flex items-center gap-2">
                      <span class="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[11px]">2</span>
                      <h3 class="font-extrabold text-slate-900 text-sm">Select Government Health Centre or Camp</h3>
                    </div>
                    <span class="text-[11px] text-slate-500 font-medium">Public Facilities &amp; Outreach Camps</span>
                  </div>

                  <div>
                    <select id="reg-center-select" required class="w-full p-3 rounded-xl border border-slate-300 font-semibold focus:outline-sky-500 bg-white shadow-xs">
                      <optgroup label="🏥 Public Healthcare Facilities (PHC / CHC / Hospital)">
                        ${state.facilities.map(f => `
                          <option value="fac_${f.facility_id}" ${(preselectedCenter && preselectedCenter.facility_id === f.facility_id) || (!preselectedCenter && nearestRecommendation.facility_id === f.facility_id) ? 'selected' : ''}>
                            ${f.name} (${f.type} • PIN: ${f.pincode || 'Local'} • ${f.operating_hours})
                          </option>
                        `).join('')}
                      </optgroup>
                      <optgroup label="🏕️ Upcoming Outreach Health Camps">
                        ${state.camps.filter(c => c.status === 'upcoming').map(c => `
                          <option value="camp_${c.camp_id}" ${preselectedCenter && preselectedCenter.camp_id === c.camp_id ? 'selected' : ''}>
                            [Camp] ${c.name} — ${c.area_name} (${c.date} • ${c.time})
                          </option>
                        `).join('')}
                      </optgroup>
                    </select>
                  </div>
                </div>

                <!-- Step 3: Clinical Service Needed & Schedule -->
                <div class="space-y-3">
                  <div class="flex items-center gap-2 border-b border-slate-100 pb-2">
                    <span class="w-5 h-5 rounded-full bg-slate-900 text-white flex items-center justify-center font-bold text-[11px]">3</span>
                    <h3 class="font-extrabold text-slate-900 text-sm">Service Requested &amp; Time Slot</h3>
                  </div>

                  <div class="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label class="block font-bold text-slate-700 mb-1">Service Needed *</label>
                      <select id="reg-service" required class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-slate-50 focus:bg-white">
                        <option value="General OPD Consultation & Routine Checkup">General OPD Consultation &amp; Routine Checkup</option>
                        <option value="Hypertension / BP Screening & Medication Refill">Hypertension (High BP) Screening &amp; Drug Refill</option>
                        <option value="Diabetes Blood Sugar Screening & Counseling">Diabetes / Blood Sugar Screening</option>
                        <option value="Maternal & Antenatal Care (ANC Checkup)">Maternal &amp; Antenatal Checkup (ANC)</option>
                        <option value="Child Immunization & Routine Vaccination">Child Immunization / Routine Vaccination</option>
                        <option value="Eye Examination & Cataract Assessment">Eye Screening &amp; Cataract Assessment</option>
                        <option value="Essential Free Medicine Refill">Essential Free Medicine Refill</option>
                        <option value="Diagnostic Lab Testing (Blood / Urine)">Diagnostic Lab Testing (Blood Sugar, Hb)</option>
                      </select>
                    </div>

                    <div class="grid grid-cols-2 gap-2">
                      <div>
                        <label class="block font-bold text-slate-700 mb-1">Preferred Date *</label>
                        <input type="date" id="reg-date" required value="${new Date(Date.now() + 86400000).toISOString().split('T')[0]}" min="${new Date().toISOString().split('T')[0]}" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-slate-50 focus:bg-white font-mono" />
                      </div>
                      <div>
                        <label class="block font-bold text-slate-700 mb-1">Time Slot *</label>
                        <select id="reg-slot" required class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-slate-50 focus:bg-white">
                          <option value="09:00 AM - 12:00 PM (Morning)">09:00 AM - 12:00 PM (Morning)</option>
                          <option value="01:00 PM - 04:00 PM (Afternoon)">01:00 PM - 04:00 PM (Afternoon)</option>
                          <option value="04:00 PM - 06:00 PM (Evening OPD)">04:00 PM - 06:00 PM (Evening OPD)</option>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div>
                    <label class="block font-bold text-slate-700 mb-1">Health Symptoms or Prior Prescriptions (Optional)</label>
                    <textarea id="reg-notes" rows="2" placeholder="e.g. Mild headache, taking BP medication, or 2nd antenatal follow-up..." class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-slate-50 focus:bg-white"></textarea>
                  </div>
                </div>

                <!-- Reassurance Banner & Submit -->
                <div class="pt-2 border-t border-slate-100 flex flex-col sm:flex-row items-center justify-between gap-4">
                  <div class="text-[11px] text-slate-500 flex items-center gap-1.5">
                    <span class="text-emerald-600 font-bold text-sm">🛡️</span>
                    <span>100% Free Public Health Service • No login or confidential records stored.</span>
                  </div>
                  <button type="submit" class="w-full sm:w-auto bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white px-8 py-3 rounded-xl font-extrabold text-sm shadow-md transition flex items-center justify-center gap-2">
                    <span>🎫</span> ${t('btnBookVisit')}
                  </button>
                </div>
              </form>
            </div>

            <!-- Right Col: Why Register & Guide -->
            <div class="space-y-4">
              <div class="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs space-y-3">
                <div class="flex items-center gap-2 font-extrabold text-slate-900 text-sm">
                  <span>✨</span> How Citizen Token Registration Works
                </div>
                <div class="space-y-3 text-xs text-slate-600 leading-relaxed">
                  <div class="flex gap-2">
                    <span class="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0">1</span>
                    <span><strong>Locate Closest Centre:</strong> The system matches your postal PIN code or locality to the nearest public health facility or outreach camp.</span>
                  </div>
                  <div class="flex gap-2">
                    <span class="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0">2</span>
                    <span><strong>Instant Digital Pass:</strong> You receive an official token number (e.g. <code>SC-4131-01</code>) with QR code.</span>
                  </div>
                  <div class="flex gap-2">
                    <span class="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0">3</span>
                    <span><strong>Priority OPD Access:</strong> Show the digital pass on your phone or printed slip at the clinic counter for zero-queue entry.</span>
                  </div>
                </div>
              </div>

              <!-- Quick Demonstration Card -->
              <div class="bg-amber-50 border border-amber-200 rounded-2xl p-5 space-y-2 text-xs text-amber-900">
                <div class="font-bold flex items-center gap-1.5 text-amber-950">
                  <span>⚡</span> Instant Demo Fill (Village B Citizen)
                </div>
                <p class="leading-relaxed">
                  Testing for the judges? Click below to instantly fill the form with resident "Karan Chavan" visiting Indapur Sub-District Hospital (PIN 413120).
                </p>
                <button id="btn-quick-fill-reg" class="w-full mt-1 bg-amber-600 hover:bg-amber-700 text-white font-bold py-2 rounded-xl transition shadow-xs">
                  Fill Demo Resident: Karan Chavan (PIN 413120)
                </button>
              </div>
            </div>
          </div>
        ` : `
          <!-- VIEW 2: MY REGISTERED PASSES -->
          <div class="space-y-4">
            <div class="flex justify-between items-center bg-white p-4 rounded-xl border border-slate-200 text-xs">
              <span class="font-bold text-slate-700">All Registered Visits &amp; Digital Passes (${activePasses.length})</span>
              <button id="btn-goto-book-tab" class="bg-emerald-600 hover:bg-emerald-700 text-white px-3.5 py-1.5 rounded-lg font-bold shadow-xs transition">
                ✚ Book Another Visit
              </button>
            </div>

            ${activePasses.length === 0 ? `
              <div class="bg-white rounded-2xl p-10 text-center border border-slate-200 space-y-3">
                <div class="text-4xl">🎫</div>
                <div class="font-bold text-slate-900 text-base">No active visit passes saved yet</div>
                <p class="text-xs text-slate-500 max-w-sm mx-auto">
                  Pre-register to visit your nearest Primary Health Centre or upcoming health camp to receive your instant digital entry pass.
                </p>
                <button id="btn-empty-book-now" class="bg-emerald-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-xs">
                  Book Your First Visit Now
                </button>
              </div>
            ` : `
              <div class="grid md:grid-cols-2 gap-5">
                ${activePasses.map(reg => `
                  <div class="bg-white rounded-2xl border ${reg.status === 'visited' ? 'border-emerald-300 bg-emerald-50/10' : 'border-slate-200'} shadow-xs hover:shadow-md transition p-6 space-y-4 flex flex-col justify-between">
                    <div class="space-y-3">
                      <!-- Top Token Bar -->
                      <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                        <div class="flex items-center gap-2">
                          <span class="font-mono font-black text-sm px-2.5 py-1 rounded-lg bg-sky-100 text-sky-800 border border-sky-200">
                            ${reg.token_number}
                          </span>
                          <span class="text-[11px] font-bold px-2 py-0.5 rounded-full ${
                            reg.status === 'visited' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' : 'bg-amber-100 text-amber-800 border border-amber-200'
                          }">
                            ${reg.status === 'visited' ? '✓ Visited / Screened' : '● Confirmed Pass'}
                          </span>
                        </div>
                        <span class="text-[11px] font-mono text-slate-400">PIN: ${reg.pincode || 'Local'}</span>
                      </div>

                      <!-- Patient & Centre -->
                      <div>
                        <h3 class="text-base font-extrabold text-slate-900">${reg.patient_name}</h3>
                        <div class="text-xs text-slate-500 mt-0.5">${reg.age} yrs • ${reg.gender} • 📞 ${reg.phone}</div>
                      </div>

                      <div class="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs space-y-1">
                        <div class="font-bold text-slate-800 flex items-center gap-1">
                          <span>🏥</span> ${reg.center_name}
                        </div>
                        <div class="text-slate-500 text-[11px]">${reg.center_address}</div>
                        <div class="text-slate-500 text-[11px]">Helpline: <a href="tel:${reg.center_phone}" class="font-bold text-sky-600 underline">${reg.center_phone}</a></div>
                      </div>

                      <!-- Service & Timing -->
                      <div class="grid grid-cols-2 gap-2 text-xs">
                        <div class="p-2 rounded-lg bg-slate-50 border">
                          <span class="text-[10px] uppercase font-bold text-slate-400 block">Service:</span>
                          <span class="font-bold text-slate-800">${reg.service_needed}</span>
                        </div>
                        <div class="p-2 rounded-lg bg-slate-50 border">
                          <span class="text-[10px] uppercase font-bold text-slate-400 block">Slot:</span>
                          <span class="font-bold text-slate-800">${reg.visit_date} (${reg.time_slot.split(' ')[0]})</span>
                        </div>
                      </div>
                    </div>

                    <!-- Bottom Actions -->
                    <div class="pt-3 border-t border-slate-100 flex items-center justify-between text-xs gap-2">
                      <button class="pass-view-btn bg-sky-600 hover:bg-sky-700 text-white px-3.5 py-1.5 rounded-xl font-bold shadow-xs transition flex items-center gap-1" data-reg-id="${reg.id}">
                        <span>🖨️</span> View &amp; Print Pass
                      </button>
                      <div class="flex items-center gap-2">
                        <a href="https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(reg.center_name + ' ' + reg.center_address)}" target="_blank" rel="noopener noreferrer" class="font-semibold text-slate-500 hover:text-slate-800">
                          Directions ↗
                        </a>
                        <button class="pass-cancel-btn text-rose-500 hover:text-rose-700 font-semibold text-[11px]" data-reg-id="${reg.id}">
                          Cancel
                        </button>
                      </div>
                    </div>
                  </div>
                `).join('')}
              </div>
            `}
          </div>
        `}
      </div>
    `;

    // Event Listeners for Register Tab
    const btnBookTab = document.getElementById('tab-btn-book');
    const btnPassesTab = document.getElementById('tab-btn-passes');
    if (btnBookTab) {
      btnBookTab.onclick = () => {
        state.selectedRegisterTab = 'book';
        renderRegister(container);
      };
    }
    if (btnPassesTab) {
      btnPassesTab.onclick = () => {
        state.selectedRegisterTab = 'passes';
        renderRegister(container);
      };
    }

    const btnGotoBook = document.getElementById('btn-goto-book-tab');
    if (btnGotoBook) {
      btnGotoBook.onclick = () => {
        state.selectedRegisterTab = 'book';
        renderRegister(container);
      };
    }

    const btnEmptyBook = document.getElementById('btn-empty-book-now');
    if (btnEmptyBook) {
      btnEmptyBook.onclick = () => {
        state.selectedRegisterTab = 'book';
        renderRegister(container);
      };
    }

    const btnUseRec = document.getElementById('btn-use-recommended');
    if (btnUseRec) {
      btnUseRec.onclick = () => {
        const select = document.getElementById('reg-center-select');
        if (select) {
          const recTarget = preselectedCenter ? (preselectedCenter.facility_id ? `fac_${preselectedCenter.facility_id}` : `camp_${preselectedCenter.camp_id}`) : `fac_${nearestRecommendation.facility_id}`;
          select.value = recTarget;
          showToast(`Selected ${preselectedCenter ? preselectedCenter.name : nearestRecommendation.name}!`, "success");
        }
      };
    }

    const btnDetectLoc = document.getElementById('btn-detect-loc');
    if (btnDetectLoc) {
      btnDetectLoc.onclick = () => {
        const pinVal = document.getElementById('reg-pincode').value.trim();
        if (pinVal) {
          executeSearch(pinVal, 'register');
        }
      };
    }

    const btnQuickFill = document.getElementById('btn-quick-fill-reg');
    if (btnQuickFill) {
      btnQuickFill.onclick = () => {
        document.getElementById('reg-name').value = "Karan Chavan";
        document.getElementById('reg-age').value = "34";
        document.getElementById('reg-gender').value = "Male";
        document.getElementById('reg-phone').value = "+91 98220 99412";
        document.getElementById('reg-pincode').value = "413120";
        document.getElementById('reg-center-select').value = "fac_F02";
        document.getElementById('reg-service').value = "Hypertension / BP Screening & Medication Refill";
        document.getElementById('reg-notes').value = "Routine health screening, check blood pressure and fasting glucose.";
        showToast("Demo resident 'Karan Chavan' filled! Click 'Book Visit' below.", "info");
      };
    }

    const form = document.getElementById('user-registration-form');
    if (form) {
      form.onsubmit = (e) => {
        e.preventDefault();
        const centerVal = document.getElementById('reg-center-select').value;
        const [type, id] = centerVal.split('_');

        let centerObj = null;
        if (type === 'camp') {
          centerObj = state.camps.find(c => c.camp_id === id);
        } else {
          centerObj = state.facilities.find(f => f.facility_id === id);
        }

        const formData = {
          patient_name: document.getElementById('reg-name').value.trim(),
          age: document.getElementById('reg-age').value.trim(),
          gender: document.getElementById('reg-gender').value,
          phone: document.getElementById('reg-phone').value.trim(),
          pincode: document.getElementById('reg-pincode').value.trim(),
          locality: pinInfo ? `${pinInfo.postOffices[0]}, ${pinInfo.district}` : 'Locality',
          center_type: type === 'camp' ? 'camp' : 'facility',
          center_id: id,
          center_name: centerObj ? centerObj.name : 'Health Centre',
          center_address: centerObj ? (centerObj.venue || centerObj.address) : 'Local Health Facility',
          center_phone: centerObj ? (centerObj.contact_phone || '+91 20 2612 0000') : '+91 20 2612 0000',
          center_distance_km: centerObj ? (centerObj.distance_km || 2.5) : 2.5,
          service_needed: document.getElementById('reg-service').value,
          visit_date: document.getElementById('reg-date').value,
          time_slot: document.getElementById('reg-slot').value,
          notes: document.getElementById('reg-notes').value.trim()
        };

        registerUserVisit(formData);
      };
    }

    // Pass cards triggers
    document.querySelectorAll('.pass-view-btn').forEach(btn => {
      btn.onclick = () => openVisitPassModal(btn.dataset.regId);
    });

    document.querySelectorAll('.pass-cancel-btn').forEach(btn => {
      btn.onclick = () => {
        if (confirm("Are you sure you want to cancel this visit pass?")) {
          cancelRegistration(btn.dataset.regId);
        }
      };
    });
  }

  // --- View: Area Priority Map (Feature 5) ---
  function renderMap(container) {
    const analyzed = analyzeHealthcareGaps(state.communities, state.facilities, state.camps);

    container.innerHTML = `
      <div class="space-y-6 py-6">
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-2xl font-black text-slate-900 tracking-tight">Community Area Priority Map</h2>
              <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-rose-100 text-rose-800 border border-rose-200">Feature 5</span>
            </div>
            <p class="text-xs text-slate-500 mt-1">
              Geographic visualization of healthcare access gaps, public facilities, and scheduled outreach camps.
            </p>
          </div>

          <!-- Map Legend -->
          <div class="flex flex-wrap items-center gap-3 bg-slate-50 p-2.5 rounded-xl border border-slate-200 text-xs font-semibold">
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-3 rounded-full bg-rose-500 inline-block"></span>
              <span>High Priority Gap (&lt;20%)</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-3 rounded-full bg-amber-500 inline-block"></span>
              <span>Medium Priority</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="w-3 h-3 rounded-full bg-emerald-500 inline-block"></span>
              <span>Baseline Served</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="text-sm">🏥</span>
              <span>Public Facilities</span>
            </div>
            <div class="flex items-center gap-1.5">
              <span class="text-sm">🏕️</span>
              <span>Health Camps</span>
            </div>
          </div>
        </div>

        <!-- Leaflet Map Container -->
        <div class="bg-white p-3 rounded-3xl border border-slate-200 shadow-sm">
          <div id="priority-map" class="rounded-2xl overflow-hidden" style="height: 520px; width: 100%;"></div>
        </div>

        <!-- Quick Map Inspector / Community Cards -->
        <div class="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs space-y-3">
          <div class="font-bold text-slate-900 text-sm">Quick Jump to Highlighted Areas:</div>
          <div class="flex flex-wrap gap-2 text-xs">
            ${analyzed.map(c => `
              <button class="map-jump-btn px-3 py-1.5 rounded-lg border font-semibold transition ${
                c.priority === 'high' ? 'bg-rose-50 text-rose-800 border-rose-300 hover:bg-rose-100' :
                c.priority === 'medium' ? 'bg-amber-50 text-amber-800 border-amber-300 hover:bg-amber-100' :
                'bg-emerald-50 text-emerald-800 border-emerald-300 hover:bg-emerald-100'
              }" data-lat="${c.latitude}" data-lng="${c.longitude}" data-name="${c.area_name}">
                ${c.area_name.split(' (')[0]}: ${c.coveragePercent}%
              </button>
            `).join('')}
          </div>
        </div>
      </div>
    `;

    // Initialize Leaflet Map
    setTimeout(() => {
      initPriorityMap(analyzed);
    }, 100);
  }

  function initPriorityMap(analyzed) {
    if (!window.L) return;

    const mapContainer = document.getElementById('priority-map');
    if (!mapContainer) return;

    const centerLat = 18.5204;
    const centerLng = 74.0500;

    if (state.mapInstance) {
      state.mapInstance.remove();
      state.mapInstance = null;
    }

    const map = window.L.map('priority-map').setView([centerLat, centerLng], 9);
    state.mapInstance = map;

    window.L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
      attribution: '© OpenStreetMap contributors | Swasthya Connect Prototype',
      maxZoom: 18
    }).addTo(map);

    // Plot Communities with Priority Circles
    analyzed.forEach(comm => {
      const color = comm.priority === 'high' ? '#ef4444' : comm.priority === 'medium' ? '#f59e0b' : '#10b981';
      const circle = window.L.circleMarker([comm.latitude, comm.longitude], {
        radius: comm.priority === 'high' ? 14 : 10,
        fillColor: color,
        color: '#ffffff',
        weight: 2,
        opacity: 1,
        fillOpacity: 0.85
      }).addTo(map);

      circle.bindPopup(`
        <div class="space-y-2 p-1 text-xs">
          <div class="font-extrabold text-sm text-slate-900">${comm.area_name}</div>
          <div class="flex items-center gap-2">
            <span class="px-2 py-0.5 rounded text-[10px] font-bold ${comm.badgeClass}">
              ${comm.priorityLabel}
            </span>
            <span class="font-bold text-slate-800">${comm.coveragePercent}% Coverage</span>
          </div>
          <div class="text-slate-600 text-[11px] space-y-0.5">
            <div>• PIN Code: <strong>${comm.pincode}</strong></div>
            <div>• Population: <strong>${comm.population.toLocaleString()}</strong></div>
            <div>• People Screened: <strong>${comm.people_screened}</strong></div>
            <div>• Nearest Facility: <strong>${comm.nearest_facility_km} km</strong></div>
          </div>
          <div class="pt-1.5 border-t border-slate-100 flex gap-2">
            <button onclick="window.swasthyaConnect.openScheduleCampModal({ prefillAreaId: '${comm.area_id}' })" class="bg-sky-600 text-white px-2.5 py-1 rounded text-[11px] font-bold">
              + Schedule Camp
            </button>
          </div>
        </div>
      `);
    });

    // Plot Public Facilities with Hospital Markers
    state.facilities.forEach(fac => {
      const facMarker = window.L.marker([fac.latitude, fac.longitude]).addTo(map);
      facMarker.bindPopup(`
        <div class="space-y-1.5 p-1 text-xs">
          <div class="text-[10px] font-bold text-sky-700 uppercase">${fac.type}</div>
          <div class="font-extrabold text-sm text-slate-900">${fac.name}</div>
          <div class="text-slate-500 text-[11px]">${fac.address}</div>
          <div class="text-emerald-700 font-semibold text-[11px]">📞 ${fac.contact_phone}</div>
          <div class="text-[10px] text-slate-400 italic">${fac.operating_hours}</div>
        </div>
      `);
    });

    // Plot Health Camps
    state.camps.forEach(camp => {
      if (camp.latitude && camp.longitude) {
        const campMarker = window.L.circleMarker([camp.latitude, camp.longitude], {
          radius: 8,
          fillColor: '#0284c7',
          color: '#ffffff',
          weight: 2,
          opacity: 1,
          fillOpacity: 0.9
        }).addTo(map);

        campMarker.bindPopup(`
          <div class="space-y-1.5 p-1 text-xs">
            <span class="px-2 py-0.5 rounded text-[10px] font-bold ${camp.status === 'upcoming' ? 'bg-sky-100 text-sky-800' : 'bg-slate-200 text-slate-700'}">
              ${camp.status === 'upcoming' ? 'Upcoming Health Camp' : 'Completed Camp'}
            </span>
            <div class="font-extrabold text-sm text-slate-900">${camp.name}</div>
            <div class="text-slate-600 text-[11px]">📅 ${camp.date} • ${camp.time}</div>
            <div class="text-slate-500 text-[11px]">📍 ${camp.venue} (PIN: ${camp.pincode || 'Local'})</div>
            <div class="pt-1">
              <button onclick="window.swasthyaConnect.openCampDetailsModal('${camp.camp_id}')" class="text-sky-600 font-bold hover:underline text-[11px]">
                View Details →
              </button>
            </div>
          </div>
        `);
      }
    });

    // Jump Buttons
    document.querySelectorAll('.map-jump-btn').forEach(btn => {
      btn.onclick = () => {
        const lat = parseFloat(btn.dataset.lat);
        const lng = parseFloat(btn.dataset.lng);
        map.flyTo([lat, lng], 13, { duration: 1.2 });
      };
    });
  }

  // --- View: Outreach & Education (Feature 4) ---
  function renderEducation(container) {
    container.innerHTML = `
      <div class="space-y-6 py-6">
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs space-y-2">
          <div class="flex items-center gap-2">
            <h2 class="text-2xl font-black text-slate-900 tracking-tight">Outreach &amp; Follow-up Information</h2>
            <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-100 text-teal-800 border border-teal-200">Feature 4</span>
          </div>
          <p class="text-xs text-slate-500">
            Educational guidance, recommended screening frequencies, and post-camp follow-up instructions for residents.
          </p>
        </div>

        <!-- Educational Cards -->
        <div class="grid md:grid-cols-2 gap-6">
          ${state.education.map(item => `
            <div class="bg-white rounded-2xl border border-slate-200 shadow-xs p-6 space-y-4">
              <div class="space-y-1">
                <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-50 text-teal-800 border border-teal-200">
                  ${item.category}
                </span>
                <h3 class="font-extrabold text-slate-900 text-lg leading-tight mt-1.5">
                  ${item.title}
                </h3>
                <p class="text-xs text-slate-600 leading-relaxed">${item.summary}</p>
              </div>

              <div class="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-3 rounded-xl border border-slate-100">
                <div>
                  <div class="text-slate-400 font-bold uppercase text-[10px]">Healthy Range:</div>
                  <div class="font-bold text-slate-800 mt-0.5">${item.ideal_reading}</div>
                </div>
                <div>
                  <div class="text-slate-400 font-bold uppercase text-[10px]">Screening Frequency:</div>
                  <div class="font-bold text-slate-800 mt-0.5">${item.frequency}</div>
                </div>
              </div>

              <div>
                <div class="text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">Key Health Points:</div>
                <ul class="text-xs text-slate-600 space-y-1 list-disc list-inside">
                  ${item.key_points.map(pt => `<li>${pt}</li>`).join('')}
                </ul>
              </div>

              <div class="p-3 rounded-xl bg-amber-50 border border-amber-200 text-xs text-amber-900">
                <span class="font-bold">Follow-Up Action:</span> ${item.follow_up_advice}
              </div>
            </div>
          `).join('')}
        </div>

        <!-- Active User Reminders Section -->
        <div class="bg-white rounded-2xl border border-slate-200 p-6 shadow-xs space-y-4">
          <div class="flex items-center justify-between">
            <div>
              <h3 class="font-bold text-slate-900 text-base">Your Active Screening Reminders</h3>
              <p class="text-xs text-slate-500">Saved reminders for scheduled community camps (stored locally on your device).</p>
            </div>
            <button id="add-custom-reminder-btn" class="bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold px-3 py-1.5 rounded-lg border transition">
              + New Reminder
            </button>
          </div>

          ${state.reminders.length === 0 ? `
            <div class="p-6 text-center bg-slate-50 rounded-xl border border-dashed border-slate-300 text-xs text-slate-500">
              No reminders active yet. Go to <button class="nav-shortcut text-sky-600 font-bold underline" data-target="camps">Find Camps</button> and click "Set Reminder" on any upcoming event.
            </div>
          ` : `
            <div class="divide-y divide-slate-100">
              ${state.reminders.map(rem => `
                <div class="py-3 flex items-center justify-between gap-4 text-xs">
                  <div>
                    <div class="font-bold text-slate-900 text-sm">${rem.camp_name}</div>
                    <div class="text-slate-500 text-xs">📍 ${rem.area_name} • 📅 Date: ${rem.date} • Alert to: ${rem.contact}</div>
                  </div>
                  <button class="delete-reminder-btn text-rose-600 hover:text-rose-800 font-bold px-2 py-1" data-id="${rem.id}">
                    Remove
                  </button>
                </div>
              `).join('')}
            </div>
          `}
        </div>
      </div>
    `;

    document.querySelectorAll('.nav-shortcut').forEach(b => {
      b.onclick = () => navigateTo(b.dataset.target);
    });

    document.querySelectorAll('.delete-reminder-btn').forEach(b => {
      b.onclick = () => {
        state.reminders = state.reminders.filter(r => r.id !== b.dataset.id);
        saveState();
        showToast("Reminder removed.", "info");
        renderEducation(container);
      };
    });

    const addCustRemBtn = document.getElementById('add-custom-reminder-btn');
    if (addCustRemBtn) addCustRemBtn.onclick = () => openReminderModal();
  }

  // --- View: Manage Camps & Outreach Tracking (Admin Workflow) ---
  function renderAdmin(container) {
    const analyzed = analyzeHealthcareGaps(state.communities, state.facilities, state.camps);

    container.innerHTML = `
      <div class="space-y-6 py-6">
        <div class="bg-white p-6 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div>
            <div class="flex items-center gap-2">
              <h2 class="text-2xl font-black text-slate-900 tracking-tight">Manage Health Camps &amp; Outreach Tracking</h2>
              <span class="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">Admin Portal</span>
            </div>
            <p class="text-xs text-slate-500 mt-1">
              Add new events, confirm verification sources, and log post-camp screening attendance.
            </p>
          </div>
          <button id="admin-create-camp-btn" class="bg-sky-600 hover:bg-sky-700 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-sm transition flex items-center gap-1.5">
            <span>✚</span> Create New Camp
          </button>
        </div>

        <!-- Outreach Attendance Tracker Showcase Box -->
        <div class="bg-gradient-to-r from-emerald-50 to-teal-50 border border-emerald-200 rounded-2xl p-6 space-y-3">
          <div class="flex items-center gap-2 text-emerald-900 font-extrabold text-base">
            <span>📈</span> Real-Time Impact Demonstration: Record Camp Attendance
          </div>
          <p class="text-xs text-emerald-800 leading-relaxed">
            When you conduct a camp in an underserved area (e.g. Village B), enter the verified attendance count below.
            The system instantly increments the community's screening count, updates its coverage percentage, and dynamically recalculates the gap priority!
          </p>
          <div class="flex flex-wrap items-center gap-2 pt-1">
            <span class="text-xs font-bold text-emerald-900">Quick Test on Village B:</span>
            <button id="quick-village-b-camp" class="bg-emerald-600 hover:bg-emerald-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold transition shadow-xs">
              Record 150 Screened at Village B Camp (C01)
            </button>
          </div>
        </div>

        <!-- Manage Camps Table -->
        <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div class="p-5 border-b border-slate-200 flex justify-between items-center">
            <div>
              <h3 class="font-bold text-slate-900 text-base">Camp Registry &amp; Verification Status</h3>
              <p class="text-xs text-slate-500">Edit, verify, mark completed, or update attendance.</p>
            </div>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
              <thead>
                <tr class="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <th class="p-3.5">Camp Name</th>
                  <th class="p-3.5">Target Area &amp; PIN</th>
                  <th class="p-3.5">Event Date</th>
                  <th class="p-3.5">Verification Source</th>
                  <th class="p-3.5">Status</th>
                  <th class="p-3.5">Attendance</th>
                  <th class="p-3.5 text-right">Actions</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                ${state.camps.map(camp => `
                  <tr class="hover:bg-slate-50/80 transition">
                    <td class="p-3.5 font-bold text-slate-900">
                      <div>${camp.name}</div>
                      <div class="text-[11px] font-normal text-slate-500">${camp.organizer}</div>
                    </td>
                    <td class="p-3.5 font-medium text-slate-800">
                      <div>${camp.area_name}</div>
                      <div class="text-[11px] font-mono text-slate-500">PIN: ${camp.pincode || 'N/A'}</div>
                    </td>
                    <td class="p-3.5 text-slate-600">${camp.date}</td>
                    <td class="p-3.5">
                      <span class="px-2 py-0.5 rounded bg-slate-100 text-slate-600 text-[11px] font-mono">
                        ${camp.verification_source || 'Sample Demo Record'}
                      </span>
                    </td>
                    <td class="p-3.5">
                      <span class="px-2.5 py-0.5 rounded-full font-bold ${
                        camp.status === 'upcoming' ? 'bg-sky-100 text-sky-800' : 'bg-emerald-100 text-emerald-800'
                      }">
                        ${camp.status}
                      </span>
                    </td>
                    <td class="p-3.5">
                      ${camp.attendance_recorded ? `
                        <span class="font-extrabold text-emerald-600 text-sm">${camp.attendance_recorded} screened</span>
                      ` : `
                        <span class="text-slate-400 italic">Pending event</span>
                      `}
                    </td>
                    <td class="p-3.5 text-right space-x-2">
                      <button class="admin-record-btn text-xs font-bold text-emerald-600 hover:text-emerald-800 underline" data-id="${camp.camp_id}">
                        Record Attendance
                      </button>
                      <button class="admin-delete-btn text-xs font-semibold text-rose-500 hover:text-rose-700" data-id="${camp.camp_id}">
                        Delete
                      </button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>

        <!-- Citizen Centre Registrations & Desk Check-In Panel -->
        <div class="bg-white rounded-2xl border border-slate-200 shadow-xs overflow-hidden">
          <div class="p-5 border-b border-slate-200 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
            <div>
              <div class="flex items-center gap-2">
                <h3 class="font-bold text-slate-900 text-base">Citizen Centre Registrations &amp; Desk Check-In</h3>
                <span class="px-2 py-0.5 rounded-full text-xs font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">Live Intake</span>
              </div>
              <p class="text-xs text-slate-500 mt-0.5">
                View registered citizens for public facilities and health camps. Click "Mark Visited / Screened" to verify desk arrival and dynamically increment community screening numbers.
              </p>
            </div>
            <div class="text-xs font-semibold text-slate-600 bg-slate-50 px-3 py-1.5 rounded-xl border">
              Total Registrations: <span class="font-bold text-slate-900">${state.registrations.length}</span>
            </div>
          </div>

          <div class="overflow-x-auto">
            <table class="w-full text-left text-xs border-collapse">
              <thead>
                <tr class="bg-slate-50 text-slate-600 font-bold border-b border-slate-200">
                  <th class="p-3.5">Token No.</th>
                  <th class="p-3.5">Citizen Details</th>
                  <th class="p-3.5">Target Healthcare Centre / Camp</th>
                  <th class="p-3.5">Service Requested</th>
                  <th class="p-3.5">Scheduled Slot</th>
                  <th class="p-3.5">Status</th>
                  <th class="p-3.5 text-right">Desk Action</th>
                </tr>
              </thead>
              <tbody class="divide-y divide-slate-100">
                ${state.registrations.length === 0 ? `
                  <tr><td colspan="7" class="p-6 text-center text-slate-400">No citizen registrations recorded yet.</td></tr>
                ` : state.registrations.map(reg => `
                  <tr class="hover:bg-slate-50/80 transition ${reg.status === 'visited' ? 'bg-emerald-50/30' : ''}">
                    <td class="p-3.5 font-mono font-bold text-sky-700">
                      <span class="px-2 py-1 rounded bg-sky-50 border border-sky-200">${reg.token_number}</span>
                    </td>
                    <td class="p-3.5">
                      <div class="font-bold text-slate-900">${reg.patient_name}</div>
                      <div class="text-[11px] text-slate-500">${reg.age} yrs • ${reg.gender} • 📞 ${reg.phone}</div>
                      <div class="text-[11px] text-slate-400">PIN: ${reg.pincode} (${reg.locality})</div>
                    </td>
                    <td class="p-3.5">
                      <div class="font-bold text-slate-800">${reg.center_name}</div>
                      <div class="text-[11px] text-slate-500">${reg.center_address}</div>
                    </td>
                    <td class="p-3.5">
                      <span class="px-2 py-0.5 rounded text-[11px] font-medium bg-slate-100 text-slate-700 border">
                        ${reg.service_needed}
                      </span>
                    </td>
                    <td class="p-3.5 text-slate-700">
                      <div>📅 ${reg.visit_date}</div>
                      <div class="text-[11px] text-slate-500 font-medium">${reg.time_slot}</div>
                    </td>
                    <td class="p-3.5">
                      <span class="px-2.5 py-0.5 rounded-full font-bold ${
                        reg.status === 'visited' ? 'bg-emerald-100 text-emerald-800 border border-emerald-200' :
                        reg.status === 'cancelled' ? 'bg-slate-100 text-slate-500' :
                        'bg-sky-100 text-sky-800 border border-sky-200'
                      }">
                        ${reg.status === 'visited' ? '✓ Visited / Screened' : reg.status === 'cancelled' ? 'Cancelled' : '● Confirmed'}
                      </span>
                    </td>
                    <td class="p-3.5 text-right space-x-2">
                      ${reg.status !== 'visited' && reg.status !== 'cancelled' ? `
                        <button class="admin-mark-visited-btn bg-emerald-600 hover:bg-emerald-700 text-white px-2.5 py-1 rounded-lg text-xs font-bold transition shadow-xs" data-reg-id="${reg.id}">
                          ✓ Mark Visited
                        </button>
                      ` : `
                        <span class="text-xs text-slate-400 italic">Complete</span>
                      `}
                      <button class="admin-view-pass-btn text-xs font-bold text-sky-600 hover:underline" data-reg-id="${reg.id}">
                        View Pass
                      </button>
                    </td>
                  </tr>
                `).join('')}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    `;

    const adminCreateBtn = document.getElementById('admin-create-camp-btn');
    if (adminCreateBtn) adminCreateBtn.onclick = () => openScheduleCampModal();

    const quickVillageBBtn = document.getElementById('quick-village-b-camp');
    if (quickVillageBBtn) {
      quickVillageBBtn.onclick = () => {
        recordCampAttendance('C01', 150);
      };
    }

    document.querySelectorAll('.admin-record-btn').forEach(btn => {
      btn.onclick = () => openRecordAttendanceModal(btn.dataset.id);
    });

    document.querySelectorAll('.admin-delete-btn').forEach(btn => {
      btn.onclick = () => {
        if (confirm("Remove this sample camp listing?")) {
          state.camps = state.camps.filter(c => c.camp_id !== btn.dataset.id);
          saveState();
          showToast("Camp record removed.", "info");
          renderAdmin(container);
        }
      };
    });

    document.querySelectorAll('.admin-mark-visited-btn').forEach(btn => {
      btn.onclick = () => {
        markRegistrationVisited(btn.dataset.regId);
      };
    });

    document.querySelectorAll('.admin-view-pass-btn').forEach(btn => {
      btn.onclick = () => {
        openVisitPassModal(btn.dataset.regId);
      };
    });
  }

  // --- Footer ---
  function renderFooter() {
    const footer = document.getElementById('app-footer');
    if (!footer) return;

    footer.innerHTML = `
      <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-4 text-xs text-slate-500 border-t border-slate-200">
        <div class="flex flex-col sm:flex-row justify-between items-center gap-4">
          <div class="flex items-center gap-2">
            <div class="w-6 h-6 rounded-md bg-sky-600 text-white flex items-center justify-center font-bold text-xs">✚</div>
            <span class="font-bold text-slate-700">${t('appName')} — ${t('appTagline')}</span>
          </div>
          <div class="flex items-center gap-4 font-medium">
            <button class="nav-shortcut hover:text-slate-900" data-target="dashboard">${t('navDashboard')}</button>
            <button class="nav-shortcut hover:text-slate-900" data-target="camps">${t('navCamps')}</button>
            <button class="nav-shortcut hover:text-slate-900" data-target="facilities">${t('navFacilities')}</button>
            <button class="nav-shortcut hover:text-slate-900" data-target="register">${t('navRegister')}</button>
            <button class="nav-shortcut hover:text-slate-900" data-target="education">${t('navEducation')}</button>
          </div>
        </div>
        <div class="text-[11px] text-slate-400 text-center sm:text-left leading-relaxed">
          <strong>Important Hackathon Note:</strong> This platform is designed for demonstration with realistic fictional data. Fictional events are explicitly marked as Demo Data and must never be interpreted as verified real clinical appointments or hospital schedules. No personal health records or patient-identifiable data are gathered.
        </div>
      </div>
    `;

    footer.querySelectorAll('.nav-shortcut').forEach(b => {
      b.onclick = () => navigateTo(b.dataset.target);
    });
  }

  // --- Modals Layer ---
  function renderModal() {
    const modalContainer = document.getElementById('modal-container');
    if (!modalContainer) return;

    if (!state.activeModal) {
      modalContainer.classList.add('hidden');
      modalContainer.innerHTML = '';
      return;
    }

    modalContainer.classList.remove('hidden');

    switch (state.activeModal) {
      case 'camp_details':
        renderCampDetailsModal(modalContainer, state.modalData);
        break;
      case 'schedule_camp':
        renderScheduleCampModal(modalContainer, state.modalData);
        break;
      case 'record_attendance':
        renderRecordAttendanceModal(modalContainer, state.modalData);
        break;
      case 'set_reminder':
        renderReminderModal(modalContainer, state.modalData);
        break;
      case 'visit_pass':
        renderVisitPassModal(modalContainer, state.modalData);
        break;
      case 'walkthrough':
        renderWalkthroughModal(modalContainer);
        break;
      default:
        closeModal();
    }
  }

  // --- Modal: Official Digital Visit Pass / Token Slip ---
  function renderVisitPassModal(container, reg) {
    if (!reg) return;

    container.innerHTML = `
      <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-6 shadow-2xl max-h-[92vh] overflow-y-auto border-2 border-emerald-500/30">
          <!-- Pass Header -->
          <div class="flex items-start justify-between border-b border-slate-200 pb-4">
            <div class="flex items-center gap-3">
              <div class="w-12 h-12 rounded-2xl bg-gradient-to-tr from-emerald-600 to-teal-500 text-white flex items-center justify-center font-bold text-2xl shadow-md">
                ✚
              </div>
              <div>
                <div class="text-[10px] uppercase tracking-wider font-extrabold text-emerald-800">Swasthya Connect • Public Health Pass</div>
                <h2 class="text-xl font-black text-slate-900 leading-tight">Official Clinic Visit Token</h2>
                <div class="text-xs text-slate-500 mt-0.5">Government Healthcare Priority Queuing Slip</div>
              </div>
            </div>
            <button id="modal-close-btn" class="text-slate-400 hover:text-slate-700 text-2xl font-bold p-1">✕</button>
          </div>

          <!-- Token Number Box -->
          <div class="bg-gradient-to-r from-emerald-50 via-teal-50 to-sky-50 rounded-2xl p-5 border-2 border-dashed border-emerald-300 text-center space-y-1">
            <div class="text-xs font-bold text-emerald-900 uppercase tracking-widest">${t('tokenNumLabel')}</div>
            <div class="text-3xl sm:text-4xl font-mono font-black text-emerald-800 tracking-wider">
              ${reg.token_number}
            </div>
            <div class="text-[11px] text-emerald-700 font-medium">
              ✓ Verified Registration • Present at Reception / OPD Counter
            </div>
          </div>

          <!-- Pass Details Grid -->
          <div class="grid sm:grid-cols-2 gap-4 text-xs">
            <!-- Patient Demographics -->
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1.5">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Citizen Details:</div>
              <div class="font-extrabold text-slate-900 text-sm">${reg.patient_name}</div>
              <div class="text-slate-600">${reg.age} years • ${reg.gender}</div>
              <div class="text-slate-600">📞 ${reg.phone}</div>
              <div class="text-slate-500 text-[11px] font-mono">PIN: ${reg.pincode || 'Local'} (${reg.locality || 'Locality'})</div>
            </div>

            <!-- Target Centre Details -->
            <div class="bg-slate-50 p-4 rounded-2xl border border-slate-100 space-y-1.5">
              <div class="text-[10px] font-bold text-slate-400 uppercase tracking-wider">Healthcare Centre:</div>
              <div class="font-extrabold text-slate-900 text-sm">${reg.center_name}</div>
              <div class="text-slate-600">${reg.center_address}</div>
              <div class="text-slate-600">Helpline: <a href="tel:${reg.center_phone}" class="font-bold text-sky-700 underline">${reg.center_phone}</a></div>
            </div>
          </div>

          <!-- Appointment Slot & Service -->
          <div class="bg-slate-50 p-4 rounded-2xl border border-slate-100 grid grid-cols-2 gap-3 text-xs">
            <div>
              <div class="text-[10px] font-bold text-slate-400 uppercase">Service Requested:</div>
              <div class="font-extrabold text-slate-800 mt-0.5">${reg.service_needed}</div>
            </div>
            <div>
              <div class="text-[10px] font-bold text-slate-400 uppercase">Scheduled Date &amp; Shift:</div>
              <div class="font-extrabold text-slate-800 mt-0.5">📅 ${reg.visit_date} • ${reg.time_slot}</div>
            </div>
          </div>

          <!-- QR Code Matrix Visual -->
          <div class="p-4 bg-white rounded-2xl border border-slate-200 flex items-center justify-between gap-4">
            <div class="space-y-1 text-xs">
              <div class="font-bold text-slate-800">Digital OPD Check-In QR</div>
              <p class="text-slate-500 text-[11px] leading-relaxed">
                Scan with clinic barcode reader or smartphone camera for instant desk verification.
              </p>
              <div class="font-mono text-[10px] text-slate-400">ID: ${reg.id}</div>
            </div>
            <div class="p-2 bg-slate-900 rounded-xl text-white shrink-0 shadow-xs">
              <!-- SVG QR Pattern -->
              <svg width="68" height="68" viewBox="0 0 24 24" fill="currentColor">
                <path d="M2 2h7v7H2V2zm2 2v3h3V4H4zm11-2h7v7h-7V2zm2 2v3h3V4h-3zM2 15h7v7H2v-7zm2 2v3h3v-3H4zm7-13h2v2h-2V4zm0 4h2v2h-2V8zm4 7h2v2h-2v-2zm-4 4h2v2h-2v-2zm4 0h4v2h-4v-2zm4-4h2v2h-2v-2zm-8-3h2v2h-2v-2zm4 0h2v2h-2v-2zm4 0h2v2h-2v-2z"/>
              </svg>
            </div>
          </div>

          <!-- Preparation Checklist -->
          <div class="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 space-y-1">
            <div class="font-bold flex items-center gap-1.5">
              <span>📋</span> What to bring to the centre:
            </div>
            <ul class="list-disc list-inside text-[11px] space-y-0.5 text-amber-800">
              <li>Aadhaar card or Government ID (optional, recommended)</li>
              <li>Previous medical prescriptions or medication boxes</li>
              <li>Arrive 15 minutes before your shift window</li>
            </ul>
          </div>

          <!-- Action Buttons -->
          <div class="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-100 text-xs">
            <div class="flex items-center gap-2">
              <button id="modal-print-pass-btn" class="bg-slate-900 hover:bg-black text-white px-4 py-2.5 rounded-xl font-bold transition flex items-center gap-1.5 shadow-xs">
                <span>🖨️</span> Print Pass (PDF)
              </button>
              <button id="modal-sms-sim-btn" class="bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-300 px-3.5 py-2.5 rounded-xl font-bold transition flex items-center gap-1">
                <span>📲</span> Simulate SMS
              </button>
            </div>
            <button id="modal-close-action" class="bg-slate-100 hover:bg-slate-200 text-slate-700 px-5 py-2.5 rounded-xl font-bold transition">
              Close Pass
            </button>
          </div>
        </div>
      </div>
    `;

    document.getElementById('modal-close-btn').onclick = closeModal;
    document.getElementById('modal-close-action').onclick = closeModal;

    const printBtn = document.getElementById('modal-print-pass-btn');
    if (printBtn) {
      printBtn.onclick = () => {
        window.print();
      };
    }

    const smsBtn = document.getElementById('modal-sms-sim-btn');
    if (smsBtn) {
      smsBtn.onclick = () => {
        showToast(`📲 SMS sent to ${reg.phone}: "Swasthya Connect: Token ${reg.token_number} confirmed for ${reg.patient_name} at ${reg.center_name} on ${reg.visit_date} (${reg.time_slot})."`, "success");
      };
    }
  }

  function closeModal() {
    state.activeModal = null;
    state.modalData = null;
    renderModal();
  }

  // Modal: Camp Details
  function openCampDetailsModal(campId) {
    const camp = state.camps.find(c => c.camp_id === campId);
    if (!camp) return;
    state.activeModal = 'camp_details';
    state.modalData = camp;
    renderModal();
  }

  function renderCampDetailsModal(container, camp) {
    container.innerHTML = `
      <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
          <!-- Header -->
          <div class="flex items-start justify-between gap-4">
            <div>
              <span class="px-2.5 py-0.5 rounded-full text-xs font-bold ${camp.status === 'upcoming' ? 'bg-sky-100 text-sky-800' : 'bg-emerald-100 text-emerald-800'}">
                ${camp.status === 'upcoming' ? 'Upcoming Health Camp' : 'Completed Event'}
              </span>
              <h2 class="text-xl sm:text-2xl font-extrabold text-slate-900 mt-2">${camp.name}</h2>
              <div class="text-xs text-sky-700 font-semibold mt-1">📍 ${camp.area_name} ${camp.pincode ? `• PIN: ${camp.pincode}` : ''}</div>
            </div>
            <button id="modal-close-btn" class="text-slate-400 hover:text-slate-700 text-2xl font-bold p-1">✕</button>
          </div>

          <!-- Schedule & Venue -->
          <div class="grid grid-cols-2 gap-3 text-xs bg-slate-50 p-4 rounded-2xl border border-slate-100">
            <div>
              <div class="text-slate-400 font-bold uppercase text-[10px]">Date &amp; Timings</div>
              <div class="font-bold text-slate-800 mt-0.5">${camp.date} • ${camp.time}</div>
            </div>
            <div>
              <div class="text-slate-400 font-bold uppercase text-[10px]">Venue</div>
              <div class="font-bold text-slate-800 mt-0.5">${camp.venue}</div>
            </div>
            <div class="col-span-2 pt-2 border-t border-slate-200">
              <div class="text-slate-400 font-bold uppercase text-[10px]">Directions</div>
              <div class="font-medium text-slate-700 mt-0.5">${camp.directions || 'Contact local organizer for transport'}</div>
            </div>
          </div>

          <!-- Services List -->
          <div>
            <div class="text-xs font-bold text-slate-700 uppercase tracking-wider mb-2">Available Clinical Services:</div>
            <div class="flex flex-wrap gap-2">
              ${camp.services.map(s => `
                <span class="px-3 py-1 rounded-lg text-xs font-semibold bg-sky-50 text-sky-800 border border-sky-200">
                  ✓ ${s}
                </span>
              `).join('')}
            </div>
          </div>

          <!-- Eligibility & Instructions -->
          <div class="space-y-3 text-xs">
            <div>
              <span class="font-bold text-slate-900">Eligibility:</span>
              <span class="text-slate-600"> ${camp.eligibility}</span>
            </div>
            <div>
              <span class="font-bold text-slate-900">What to Bring:</span>
              <span class="text-slate-600"> ${camp.instructions || 'Bring Aadhaar Card and previous medical prescriptions if available.'}</span>
            </div>
            <div>
              <span class="font-bold text-slate-900">Organized By:</span>
              <span class="text-slate-600"> ${camp.organizer}</span>
            </div>
            <div>
              <span class="font-bold text-slate-900">Verified Contact:</span>
              <span class="text-slate-600"> ${camp.contact_person} (<a href="tel:${camp.contact_phone}" class="text-sky-600 font-bold underline">${camp.contact_phone}</a>)</span>
            </div>
          </div>

          <!-- Verification Banner -->
          <div class="p-3 bg-amber-50 rounded-xl border border-amber-200 text-xs text-amber-900 flex items-center justify-between">
            <span><strong>Listing Source:</strong> ${camp.verification_source || 'Taluka Health Department Circular (Sample)'}</span>
            <span class="font-mono text-[10px] text-amber-700">sample_only</span>
          </div>

          <!-- Actions -->
          <div class="flex justify-end gap-3 pt-2 border-t border-slate-100">
            <button id="modal-close-action" class="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900">Close</button>
            ${camp.status === 'upcoming' ? `
              <button id="modal-set-rem-btn" class="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-xl text-xs font-bold shadow-md transition">
                🔔 Set Screening Reminder
              </button>
            ` : ''}
          </div>
        </div>
      </div>
    `;

    document.getElementById('modal-close-btn').onclick = closeModal;
    document.getElementById('modal-close-action').onclick = closeModal;
    const setRemBtn = document.getElementById('modal-set-rem-btn');
    if (setRemBtn) {
      setRemBtn.onclick = () => {
        closeModal();
        openReminderModal(camp.camp_id);
      };
    }
  }

  // Modal: Schedule New Camp
  function openScheduleCampModal(opts = {}) {
    state.activeModal = 'schedule_camp';
    state.modalData = opts;
    renderModal();
  }

  function renderScheduleCampModal(container, data = {}) {
    const prefillArea = data.prefillAreaId ? state.communities.find(c => c.area_id === data.prefillAreaId) : null;
    const prefillPin = data.prefillPincode || (prefillArea ? prefillArea.pincode : '');
    const prefillDistrict = data.prefillDistrict || (prefillArea ? prefillArea.district : 'Pune');

    container.innerHTML = `
      <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-xl w-full p-6 sm:p-8 space-y-5 shadow-2xl max-h-[90vh] overflow-y-auto">
          <div class="flex items-start justify-between">
            <div>
              <h2 class="text-xl font-black text-slate-900">Schedule Outreach Health Camp</h2>
              <p class="text-xs text-slate-500 mt-0.5">Plan a targeted screening event for an underserved community or PIN code.</p>
            </div>
            <button id="modal-close-btn" class="text-slate-400 hover:text-slate-700 text-2xl font-bold">✕</button>
          </div>

          <form id="new-camp-form" class="space-y-4 text-xs">
            <div>
              <label class="block font-bold text-slate-700 mb-1">Target Community / Locality *</label>
              <select id="form-area-id" required class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-white">
                ${state.communities.map(c => `
                  <option value="${c.area_id}" ${prefillArea && prefillArea.area_id === c.area_id ? 'selected' : ''}>
                    ${c.area_name} (${c.district} - PIN ${c.pincode}) — ${((c.people_screened/c.population)*100).toFixed(1)}% coverage
                  </option>
                `).join('')}
              </select>
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-bold text-slate-700 mb-1">Postal PIN Code *</label>
                <input type="text" id="form-pincode" required value="${prefillPin || '413120'}" class="w-full p-2.5 rounded-xl border border-slate-300 font-mono font-bold focus:outline-sky-500" />
              </div>
              <div>
                <label class="block font-bold text-slate-700 mb-1">District / City *</label>
                <input type="text" id="form-district" required value="${prefillDistrict || 'Pune'}" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
              </div>
            </div>

            <div>
              <label class="block font-bold text-slate-700 mb-1">Camp Name / Clinical Focus *</label>
              <input type="text" id="form-name" required value="Hypertension &amp; Diabetes Targeted Screening Camp" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-bold text-slate-700 mb-1">Date *</label>
                <input type="date" id="form-date" required value="2026-11-15" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
              </div>
              <div>
                <label class="block font-bold text-slate-700 mb-1">Timings *</label>
                <input type="text" id="form-time" required value="09:00 AM - 02:00 PM" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
              </div>
            </div>

            <div>
              <label class="block font-bold text-slate-700 mb-1">Venue *</label>
              <input type="text" id="form-venue" required value="Zilla Parishad Primary School Hall, Main Road" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
            </div>

            <div>
              <label class="block font-bold text-slate-700 mb-1">Clinical Services Offered (Comma separated)</label>
              <input type="text" id="form-services" value="Blood pressure screening, Blood sugar test, Doctor consultation" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
            </div>

            <div class="grid grid-cols-2 gap-3">
              <div>
                <label class="block font-bold text-slate-700 mb-1">Medical Officer / Contact Person</label>
                <input type="text" id="form-contact-person" value="Dr. Outreach Coordinator" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
              </div>
              <div>
                <label class="block font-bold text-slate-700 mb-1">Contact Phone</label>
                <input type="text" id="form-contact-phone" value="+91 98220 00000" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
              </div>
            </div>

            <div>
              <label class="block font-bold text-slate-700 mb-1">Verification Confirmation Source</label>
              <input type="text" id="form-source" value="Taluka Medical Officer Work Order (Sample Demo Record)" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
            </div>

            <div class="flex justify-end gap-3 pt-3 border-t border-slate-100">
              <button type="button" id="modal-cancel-btn" class="px-4 py-2 font-semibold text-slate-600 hover:text-slate-900">Cancel</button>
              <button type="submit" class="bg-sky-600 hover:bg-sky-700 text-white px-5 py-2 rounded-xl font-bold shadow-md transition">Publish Camp</button>
            </div>
          </form>
        </div>
      </div>
    `;

    document.getElementById('modal-close-btn').onclick = closeModal;
    document.getElementById('modal-cancel-btn').onclick = closeModal;

    const form = document.getElementById('new-camp-form');
    form.onsubmit = (e) => {
      e.preventDefault();
      const areaId = document.getElementById('form-area-id').value;
      const targetComm = state.communities.find(c => c.area_id === areaId);

      const servicesArray = document.getElementById('form-services').value
        .split(',')
        .map(s => s.trim())
        .filter(Boolean);

      const pincodeVal = document.getElementById('form-pincode').value.trim();
      const districtVal = document.getElementById('form-district').value.trim();

      const newCamp = {
        camp_id: "C-" + Date.now().toString().slice(-4),
        name: document.getElementById('form-name').value.trim(),
        area_id: areaId,
        area_name: targetComm ? targetComm.area_name : "Locality",
        district: districtVal,
        pincode: pincodeVal,
        taluka: targetComm ? targetComm.sub_district : "Taluka",
        date: document.getElementById('form-date').value,
        time: document.getElementById('form-time').value.trim(),
        venue: document.getElementById('form-venue').value.trim(),
        services: servicesArray.length ? servicesArray : ["General Health Screening"],
        service_types: ["Screening", "General OPD"],
        eligibility: "Open to all local residents",
        target_population: "Community Residents",
        organizer: "District Health Society & Local Panchayat",
        contact_person: document.getElementById('form-contact-person').value.trim(),
        contact_phone: document.getElementById('form-contact-phone').value.trim(),
        status: "upcoming",
        verification_status: "sample_only",
        verification_source: document.getElementById('form-source').value.trim(),
        latitude: targetComm ? targetComm.latitude : 18.5204,
        longitude: targetComm ? targetComm.longitude : 74.0500,
        directions: "Near Gram Panchayat Bhavan",
        attendance_recorded: null,
        instructions: "Bring Aadhaar card and prior prescription slips if available."
      };

      addNewCamp(newCamp);
      closeModal();
    };
  }

  // Modal: Record Attendance
  function openRecordAttendanceModal(campId) {
    const camp = state.camps.find(c => c.camp_id === campId);
    state.activeModal = 'record_attendance';
    state.modalData = camp;
    renderModal();
  }

  function renderRecordAttendanceModal(container, camp) {
    container.innerHTML = `
      <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 shadow-2xl">
          <div class="flex items-start justify-between">
            <div>
              <h2 class="text-lg font-black text-slate-900">Record Outreach Attendance</h2>
              <p class="text-xs text-slate-500 mt-0.5">Post-camp summary reporting</p>
            </div>
            <button id="modal-close-btn" class="text-slate-400 hover:text-slate-700 text-2xl font-bold">✕</button>
          </div>

          <div class="bg-slate-50 p-3 rounded-xl border border-slate-100 text-xs space-y-1">
            <div class="font-bold text-slate-800">${camp ? camp.name : 'Health Camp'}</div>
            <div class="text-slate-500">📍 ${camp ? camp.area_name : ''} (PIN: ${camp ? camp.pincode : ''})</div>
          </div>

          <form id="attendance-form" class="space-y-4 text-xs">
            <div>
              <label class="block font-bold text-slate-700 mb-1">Total People Screened *</label>
              <input type="number" id="attendance-count" required min="1" max="10000" value="150" class="w-full p-2.5 rounded-xl border border-slate-300 font-bold text-base focus:outline-sky-500" />
              <p class="text-[11px] text-slate-400 mt-1">This will increment the community's overall screening statistics and recalculate coverage.</p>
            </div>

            <div class="flex justify-end gap-3 pt-2 border-t border-slate-100">
              <button type="button" id="modal-cancel-btn" class="px-4 py-2 font-semibold text-slate-600 hover:text-slate-900">Cancel</button>
              <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-xl font-bold shadow-md transition">Save &amp; Update Coverage</button>
            </div>
          </form>
        </div>
      </div>
    `;

    document.getElementById('modal-close-btn').onclick = closeModal;
    document.getElementById('modal-cancel-btn').onclick = closeModal;

    const form = document.getElementById('attendance-form');
    form.onsubmit = (e) => {
      e.preventDefault();
      const count = document.getElementById('attendance-count').value;
      if (camp) {
        recordCampAttendance(camp.camp_id, count);
      }
      closeModal();
    };
  }

  // Modal: Set Reminder
  function openReminderModal(campId = null) {
    const camp = campId ? state.camps.find(c => c.camp_id === campId) : null;
    state.activeModal = 'set_reminder';
    state.modalData = camp;
    renderModal();
  }

  function renderReminderModal(container, camp) {
    container.innerHTML = `
      <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-md w-full p-6 sm:p-8 space-y-5 shadow-2xl">
          <div class="flex items-start justify-between">
            <div>
              <h2 class="text-lg font-black text-slate-900">Set Screening Reminder</h2>
              <p class="text-xs text-slate-500 mt-0.5">Privacy-first reminder without storing medical records.</p>
            </div>
            <button id="modal-close-btn" class="text-slate-400 hover:text-slate-700 text-2xl font-bold">✕</button>
          </div>

          <div class="p-3 bg-sky-50 rounded-xl border border-sky-100 text-xs">
            <span class="font-bold text-sky-900">Camp:</span> ${camp ? camp.name : 'Routine Community Screening'}
            <div class="text-slate-500 mt-0.5">${camp ? `📅 ${camp.date} • ${camp.venue} (PIN: ${camp.pincode})` : 'Upcoming Village Day'}</div>
          </div>

          <form id="reminder-form" class="space-y-4 text-xs">
            <div>
              <label class="block font-bold text-slate-700 mb-1">Mobile Number or Notification Name *</label>
              <input type="text" id="rem-contact" required placeholder="+91 98XXX XXXXX or 'My Phone'" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500" />
            </div>

            <div>
              <label class="block font-bold text-slate-700 mb-1">Reminder Timing</label>
              <select id="rem-time" class="w-full p-2.5 rounded-xl border border-slate-300 font-medium focus:outline-sky-500 bg-white">
                <option value="1_day_before">1 Day Before Camp</option>
                <option value="morning_of">Morning of Camp (7:00 AM)</option>
                <option value="immediate">Immediate Confirmation</option>
              </select>
            </div>

            <div class="p-2.5 bg-slate-50 rounded-xl text-[11px] text-slate-500 leading-relaxed border">
              🛡️ <strong>Privacy Protection:</strong> No personal medical history, diagnoses, or identity documents are collected or transmitted.
            </div>

            <div class="flex justify-end gap-3 pt-2 border-t border-slate-100">
              <button type="button" id="modal-cancel-btn" class="px-4 py-2 font-semibold text-slate-600 hover:text-slate-900">Cancel</button>
              <button type="submit" class="bg-emerald-600 hover:bg-emerald-700 text-white px-5 py-2 rounded-xl font-bold shadow-md transition">Confirm Reminder</button>
            </div>
          </form>
        </div>
      </div>
    `;

    document.getElementById('modal-close-btn').onclick = closeModal;
    document.getElementById('modal-cancel-btn').onclick = closeModal;

    const form = document.getElementById('reminder-form');
    form.onsubmit = (e) => {
      e.preventDefault();
      const contact = document.getElementById('rem-contact').value.trim();
      const campId = camp ? camp.camp_id : 'C01';
      registerReminder(campId, contact, camp ? camp.services[0] : 'General');
      closeModal();
    };
  }

  // Modal: Interactive 1-Click Demo Scenario Walkthrough (Section 12 of prompt)
  function openWalkthroughModal() {
    state.activeModal = 'walkthrough';
    renderModal();
  }

  function renderWalkthroughModal(container) {
    const commB = state.communities.find(c => c.area_id === 'A02') || state.communities[1];
    const commBCoverage = ((commB.people_screened / commB.population) * 100).toFixed(1);

    container.innerHTML = `
      <div class="fixed inset-0 bg-slate-900/60 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div class="bg-white rounded-3xl max-w-2xl w-full p-6 sm:p-8 space-y-6 shadow-2xl max-h-[90vh] overflow-y-auto">
          <div class="flex items-start justify-between">
            <div class="flex items-center gap-3">
              <div class="w-10 h-10 rounded-xl bg-amber-100 text-amber-800 flex items-center justify-center font-bold text-lg">
                ⚡
              </div>
              <div>
                <h2 class="text-xl sm:text-2xl font-black text-slate-900">1-Click Demo Scenario Walkthrough</h2>
                <p class="text-xs text-slate-500">Official Hackathon Judge Testing Flow (Section 12)</p>
              </div>
            </div>
            <button id="modal-close-btn" class="text-slate-400 hover:text-slate-700 text-2xl font-bold">✕</button>
          </div>

          <!-- Scenario Steps -->
          <div class="space-y-4 text-xs">
            <!-- Step 1 -->
            <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <div class="flex items-center justify-between">
                <span class="font-extrabold text-slate-900 text-sm">Step 1: Gap Identified (Village B - PIN 413120)</span>
                <span class="px-2 py-0.5 rounded text-[11px] font-bold bg-rose-100 text-rose-800">
                  Current Coverage: ${commBCoverage}%
                </span>
              </div>
              <p class="text-slate-600 leading-relaxed">
                Village B has a population of <strong>1,500</strong> with <strong>${commB.people_screened}</strong> people screened. Distance to nearest hospital is <strong>8.5 km</strong>.
                The transparent rule engine automatically flags it as <strong>High Priority</strong>.
              </p>
              <button id="step-1-btn" class="text-sky-600 hover:underline font-bold">
                → View Village B on Gap Dashboard
              </button>
            </div>

            <!-- Step 2 -->
            <div class="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
              <span class="font-extrabold text-slate-900 text-sm">Step 2: Outreach Scheduled in PIN 413120</span>
              <p class="text-slate-600 leading-relaxed">
                A specialized Hypertension &amp; Diabetes camp (C01) is scheduled at Village B's Zilla Parishad Hall with free medication refills.
              </p>
              <button id="step-2-btn" class="text-sky-600 hover:underline font-bold">
                → Open Village B Camp Details &amp; Directions
              </button>
            </div>

            <!-- Step 3 -->
            <div class="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 space-y-2 text-emerald-950">
              <span class="font-extrabold text-emerald-900 text-sm">Step 3: Execute Closed-Loop Demonstration</span>
              <p class="leading-relaxed">
                Click the button below to simulate holding the camp and recording <strong>150 attendees screened</strong>.
                Notice how Village B's screened count doubles from 150 to 300, coverage rises from 10% to 20%, and dashboard charts update live!
              </p>
              <button id="step-3-simulate-btn" class="bg-emerald-600 hover:bg-emerald-700 text-white px-4 py-2 rounded-xl font-bold shadow-sm transition">
                ⚡ Simulate Event &amp; Record 150 Attendees
              </button>
            </div>
          </div>

          <div class="flex justify-end pt-2 border-t border-slate-100">
            <button id="modal-close-action" class="px-4 py-2 text-xs font-semibold text-slate-600 hover:text-slate-900">Done</button>
          </div>
        </div>
      </div>
    `;

    document.getElementById('modal-close-btn').onclick = closeModal;
    document.getElementById('modal-close-action').onclick = closeModal;

    document.getElementById('step-1-btn').onclick = () => {
      closeModal();
      navigateTo('dashboard');
    };

    document.getElementById('step-2-btn').onclick = () => {
      closeModal();
      openCampDetailsModal('C01');
    };

    document.getElementById('step-3-simulate-btn').onclick = () => {
      closeModal();
      recordCampAttendance('C01', 150);
      navigateTo('dashboard');
    };
  }

  // --- Global Window Expose for Inline Callbacks ---
  window.swasthyaConnect = {
    navigateTo,
    openCampDetailsModal,
    openScheduleCampModal,
    openRecordAttendanceModal,
    openReminderModal,
    openRegisterWithCenter,
    openVisitPassModal,
    registerUserVisit,
    markRegistrationVisited,
    resetState,
    recordCampAttendance,
    executeSearch,
    resolvePostalPincode
  };

  // --- Bootstrap on DOM Ready ---
  document.addEventListener('DOMContentLoaded', () => {
    loadInitialData().then(() => {
      renderApp();
    });
  });

})();
